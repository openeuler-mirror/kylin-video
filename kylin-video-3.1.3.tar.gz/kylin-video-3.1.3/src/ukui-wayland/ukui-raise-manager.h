#ifndef RAISEMANAGER_H
#define RAISEMANAGER_H

#include <QWindow>

class RaiseManager
{
public:
    static class RaiseManager *getInstance();
    bool raise(QWindow *windowHandle);

private:
    RaiseManager();
};

#endif // RAISEMANAGER_H
