#include "ukui-raise-manager.h"
#include "ukui-raise-client.h"
#include <QApplication>
#include <qpa/qplatformnativeinterface.h>
#include <KWayland/Client/connection_thread.h>
#include <QDebug>
static RaiseManager *global_instance = nullptr;

static wl_display *display = nullptr;
static ukui_raise *ukui_raise_manager = nullptr;

static void handle_global(void *data, struct wl_registry *registry,
                          uint32_t name, const char *interface, uint32_t version) {
    if (strcmp(interface, ukui_raise_interface.name) == 0) {
        ukui_raise_manager = (ukui_raise *) wl_registry_bind(registry, name, &ukui_raise_interface, version);
    }
}

static void handle_global_remove(void *data, struct wl_registry *registry,uint32_t name) {}

static const struct wl_registry_listener registry_listener = {
    .global = handle_global,
    .global_remove = handle_global_remove,
};

RaiseManager *RaiseManager::getInstance()
{
    if (!global_instance)
        global_instance = new RaiseManager;
    return global_instance;
}

bool RaiseManager::raise(QWindow *windowHandle)
{
    auto nativeInterface = qApp->platformNativeInterface();
    wl_surface *surface = reinterpret_cast<wl_surface *>(nativeInterface->nativeResourceForWindow(QByteArrayLiteral("surface"), windowHandle));
    if (!surface || !ukui_raise_manager)
        return false;
    wl_proxy_marshal((struct wl_proxy *) ukui_raise_manager, 0, surface);
    wl_surface_commit(surface);
    wl_display_roundtrip(display);
    return true;
}

RaiseManager::RaiseManager()
{
    auto connectionThread = KWayland::Client::ConnectionThread::fromApplication(qApp);
    display = connectionThread->display();

    struct wl_registry *registry = wl_display_get_registry(display);
    wl_registry_add_listener(registry, &registry_listener, nullptr);
    wl_display_roundtrip(display);
}
