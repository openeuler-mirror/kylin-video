#include "waylanddialog.h"
#include "ui_waylanddialog.h"

WaylandDialog::WaylandDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::WaylandDialog)
{
    ui->setupUi(this);
    setFixedSize(400, 170);
}

WaylandDialog::~WaylandDialog()
{
    delete ui;
}

void WaylandDialog::setText(QString text)
{
    ui->textBrowser->setText(text);
}
