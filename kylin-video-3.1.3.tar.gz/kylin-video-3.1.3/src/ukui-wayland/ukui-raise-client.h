#ifndef CUSTOM_CLIENT_PROTOCOL_H1
#define CUSTOM_CLIENT_PROTOCOL_H1

#include <stdint.h>
#include <stddef.h>
#include "wayland-client.h"

#ifdef  __cplusplus
extern "C" {
#endif

struct ukui_raise;
struct wl_surface;

extern const struct wl_interface ukui_raise_interface;


#ifdef  __cplusplus
}
#endif

#endif
