#ifndef PREVIEWWIDGET_H
#define PREVIEWWIDGET_H

#include <QWidget>
#include <mutex>
#include "global/global.h"

#include <libffmpegthumbnailer/videothumbnailer.h>
using namespace ffmpegthumbnailer;

namespace Ui {
class PreviewWidget;
}

class PreviewWidget : public QWidget
{
    Q_OBJECT

public:
    explicit PreviewWidget(QWidget *parent = nullptr);
    ~PreviewWidget();

    void setHide();
    void setPreview(int time);
    void setMoveRange(int range){moveRange = range;}

    void setBlackTheme();
    void setLightTheme();

private:
    Ui::PreviewWidget *ui;
    QString currentFile;
    int videoStream = -1;
    int duration;
    int previewTime = 0;
    int moveRange = 1;

signals:
    void updatePreview();

private slots:
    void slotFileInfoChange(Mpv::FileInfo info);
    void updatePos();

protected:
    std::mutex mux;
    VideoThumbnailer *m_videoTbr;
};

#endif // PREVIEWWIDGET_H
