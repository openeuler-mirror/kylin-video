#ifndef EVENTPASSWIDGET_H
#define EVENTPASSWIDGET_H

#include <QWidget>

#include "core/mpvtypes.h"

class EventPassWidget : public QWidget
{
    Q_OBJECT
public:
    explicit EventPassWidget(QWidget *parent = nullptr);

    void setMouseUsed(bool used);

signals:
    void mousePressed();

private slots:
    void playStateChange(Mpv::PlayState state);
    void videIdChange(int vid);

private:
    void initGlobalSig();

    bool m_mouseUsed,
         m_isMouseEnter,
         m_hasVideo;

    Mpv::PlayState m_playState;

    QTimer  *m_checkMouseTimer,
            *m_lMouseClickTimer;

protected:
    void mousePressEvent(QMouseEvent *e) override;
    void mouseMoveEvent(QMouseEvent *e) override;
    void mouseDoubleClickEvent(QMouseEvent *e) override;
    void enterEvent(QEvent *e) override;
    void leaveEvent(QEvent *e) override;
};

#endif // EVENTPASSWIDGET_H
