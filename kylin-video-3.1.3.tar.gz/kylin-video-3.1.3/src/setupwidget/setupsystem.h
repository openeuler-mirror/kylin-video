#ifndef SETUPSYSTEMWIDGET_H
#define SETUPSYSTEMWIDGET_H

#include <QWidget>

namespace Ui {
class SetupSystem;
}

class SetupSystem : public QWidget
{
    Q_OBJECT

public:
    explicit SetupSystem(QWidget *parent = nullptr);
    ~SetupSystem();

    void initData();
    void setBlackTheme();
    void setLightTheme();
    void setWidgetFont(QString family, int size);

private:
    Ui::SetupSystem *ui;

    void initConnect();
};

#endif // SETUPSYSTEMWIDGET_H
