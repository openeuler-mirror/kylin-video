#ifndef SETUPCODEC_H
#define SETUPCODEC_H

#include <QWidget>

namespace Ui {
class SetupCodec;
}

class SetupCodec : public QWidget
{
    Q_OBJECT

public:
    explicit SetupCodec(QWidget *parent = nullptr);
    ~SetupCodec();

    void setBlackTheme();
    void setLightTheme();
    void setWidgetFont(QString family, int size);

private:
    Ui::SetupCodec *ui;

    void initData();
    void initConnect();
};

#endif // SETUPCODEC_H
