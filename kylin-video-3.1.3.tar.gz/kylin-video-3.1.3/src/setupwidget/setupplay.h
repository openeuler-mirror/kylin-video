#ifndef SETUPPLAYWIDGET_H
#define SETUPPLAYWIDGET_H

#include <QWidget>

namespace Ui {
class SetupPlay;
}

class SetupPlay : public QWidget
{
    Q_OBJECT

public:
    explicit SetupPlay(QWidget *parent = nullptr);
    ~SetupPlay();

    void initData();
    void setBlackTheme();
    void setLightTheme();
    void setWidgetFont(QString family, int size);

private:
    Ui::SetupPlay *ui;

    void initConnect();
};

#endif // SETUPPLAYWIDGET_H
