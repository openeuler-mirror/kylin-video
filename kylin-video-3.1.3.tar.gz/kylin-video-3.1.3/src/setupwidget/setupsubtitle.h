#ifndef SETUPSUBTITLE_H
#define SETUPSUBTITLE_H

#include <QWidget>

namespace Ui {
class SetupSubtitle;
}

class SetupSubtitle : public QWidget
{
    Q_OBJECT

public:
    explicit SetupSubtitle(QWidget *parent = nullptr);
    ~SetupSubtitle();

    void initData();
    void setBlackTheme();
    void setLightTheme();
    void setWidgetFont(QString family, int size);

private:
    Ui::SetupSubtitle *ui;
    QString subPath;

    void initConnect();
};

#endif // SETUPSUBTITLE_H
