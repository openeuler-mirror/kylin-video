#ifndef SETUPVOLUME_H
#define SETUPVOLUME_H

#include <QWidget>

namespace Ui {
class SetupVolume;
}

class SetupVolume : public QWidget
{
    Q_OBJECT

public:
    explicit SetupVolume(QWidget *parent = nullptr);
    ~SetupVolume();

    void initData();
    void setBlackTheme();
    void setLightTheme();
    void setWidgetFont(QString family, int size);

private:
    Ui::SetupVolume *ui;

    void initConnect();
};

#endif // SETUPVOLUME_H
