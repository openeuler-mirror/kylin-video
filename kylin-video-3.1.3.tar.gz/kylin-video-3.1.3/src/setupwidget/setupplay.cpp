#include "setupplay.h"
#include "ui_setupplay.h"

#include "global/global.h"

using namespace Global;

SetupPlay::SetupPlay(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::SetupPlay)
{
    ui->setupUi(this);

    QFont f("Noto Sans CJK SC Regular");
    f.setPixelSize(14);
    ui->cb_AutoFullScreen->setFont(f);
    ui->cb_AutoFullScreen->hide();

    ui->cb_ClearListExit->setFont(f);
    ui->cb_LastPosPlay->setFont(f);
    ui->cb_FindAssociatedPlay->setFont(f);

    ui->cb_FindAssociatedPlay->hide();  // 功能暂时隐藏

    initConnect();
}

SetupPlay::~SetupPlay()
{
    delete ui;
}

/** **********************************************
 * 主题颜色修改
 *************************************************/
void SetupPlay::setBlackTheme()
{
    ui->cb_AutoFullScreen->setStyleSheet(QString("color:rgb(249,249,249);"));
    ui->cb_ClearListExit->setStyleSheet(QString("color:rgb(249,249,249);"));
    ui->cb_LastPosPlay->setStyleSheet(QString("color:rgb(249,249,249);"));
    ui->cb_FindAssociatedPlay->setStyleSheet(QString("color:rgb(249,249,249);"));
}

void SetupPlay::setLightTheme()
{
    ui->cb_AutoFullScreen->setStyleSheet(QString("color:rgb(38,38,38);"));
    ui->cb_ClearListExit->setStyleSheet(QString("color:rgb(38,38,38);"));
    ui->cb_LastPosPlay->setStyleSheet(QString("color:rgb(38,38,38);"));
    ui->cb_FindAssociatedPlay->setStyleSheet(QString("color:rgb(38,38,38);"));
}

void SetupPlay::setWidgetFont(QString family, int size)
{
    QFont f(family);
    f.setPointSize(size);

    ui->cb_AutoFullScreen->setFont(f);
    ui->cb_ClearListExit->setFont(f);
    ui->cb_FindAssociatedPlay->setFont(f);
    ui->cb_LastPosPlay->setFont(f);
}

void SetupPlay::initData()
{
    ui->cb_AutoFullScreen->setChecked(gsetup->fullScreenWhenPlay.first);
    ui->cb_ClearListExit->setChecked(gsetup->clearListWhenExit.first);
    ui->cb_LastPosPlay->setChecked(gsetup->playLastPos.first);
    ui->cb_FindAssociatedPlay->setChecked(gsetup->playRelationFile.first);
}

void SetupPlay::initConnect()
{
    connect(ui->cb_AutoFullScreen, &QCheckBox::clicked, [&](bool cheched){gsetup->fullScreenWhenPlay.second = cheched;});
    connect(ui->cb_ClearListExit, &QCheckBox::clicked, [&](bool cheched){gsetup->clearListWhenExit.second = cheched;});
    connect(ui->cb_LastPosPlay, &QCheckBox::clicked, [&](bool cheched){gsetup->playLastPos.second = cheched;});
    connect(ui->cb_FindAssociatedPlay, &QCheckBox::clicked, [&](bool cheched){gsetup->playRelationFile.second = cheched;});
}
