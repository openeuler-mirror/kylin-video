#ifndef SETUPSCREENSHOT_H
#define SETUPSCREENSHOT_H

#include <QWidget>
#include <QDir>

#define DEFAULT_SAVE_PATH QDir::homePath().append(tr("Pictures"))

namespace Ui {
class SetupScreenshot;
}

class SetupScreenshot : public QWidget
{
    Q_OBJECT

public:
    explicit SetupScreenshot(QWidget *parent = nullptr);
    ~SetupScreenshot();

    void initData();
    void setBlackTheme();
    void setLightTheme();
    void setWidgetFont(QString family, int size);

private:
    Ui::SetupScreenshot *ui;
    int m_format_index;

    void initConnect();
};

#endif // SETUPSCREENSHOT_H
