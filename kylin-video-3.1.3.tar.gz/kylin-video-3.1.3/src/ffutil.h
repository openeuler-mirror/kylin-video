#ifndef FFUTIL_H
#define FFUTIL_H

#include <QObject>

#include <libffmpegthumbnailer/videothumbnailer.h>
using namespace ffmpegthumbnailer;

struct AVCodec;
struct AVCodecContext;
struct AVFormatContext;

class FFUtil : public QObject
{
    Q_OBJECT
public:
    explicit FFUtil(QObject *parent = nullptr);
    ~FFUtil();
    int open(QString _file);
    int getDuration();
    void close();
    void saveIFrame(QString _savePath);

private:
    QString m_fileName;
    VideoThumbnailer *m_videoTbr;
    AVFormatContext *pFormatCtx;
    AVCodecContext  *pCodecCtx;
    AVCodec         *pCodec;
    int videoStream;
    int videoDuration;

    int fitTime(int _duration);

signals:

};

#endif // FFUTIL_H
