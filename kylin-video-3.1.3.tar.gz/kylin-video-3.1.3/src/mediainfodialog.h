#ifndef MEDIAINFODIALOG_H
#define MEDIAINFODIALOG_H

#include <QDialog>
#include "core/mpvtypes.h"

#define IconFixedSize QSize(24,24)

namespace Ui {
class MediaInfoDialog;
}

class MediaInfoDialog : public QDialog
{
    Q_OBJECT

public:
    explicit MediaInfoDialog(QWidget *parent = nullptr);
    ~MediaInfoDialog();

    void setData(QString data);
    void ukuiMove();

private slots:
    void on_pushButton_clicked();

private:
    Ui::MediaInfoDialog *ui;

protected:
    bool eventFilter(QObject *watched, QEvent *event) override;
    void showEvent(QShowEvent *event) override;
};

#endif // MEDIAINFODIALOG_H
