#ifndef SETUPDIALOG_H
#define SETUPDIALOG_H

#include <QDialog>

namespace Ui {
class SetUpDialog;
}

class SetUpDialog : public QDialog
{
    Q_OBJECT

public:
    explicit SetUpDialog(QWidget *parent = nullptr);
    ~SetUpDialog();
    void setIndex(int index);

private:
    Ui::SetUpDialog *ui;
    void initStyle();
    void initListWidget();
    void initConnect();
    void resetFont();

private slots:
    void slotChangeTheme(bool is_black_theme);
    void showEvent(QShowEvent *e);
    void hideEvent(QHideEvent *e);
    bool eventFilter(QObject *watched, QEvent *event);
};

#endif // SETUPDIALOG_H
