#ifndef PLAYGLWIDGET_H
#define PLAYGLWIDGET_H

#include <QOpenGLWidget>
#include <mpv/client.h>
#include <mpv/opengl_cb.h>
#include <mpv/qthelper.hpp>

#include "core/mpvtypes.h"

class PlayGLWidget : public QWidget
{
public:
    PlayGLWidget(QWidget *parent = 0, Qt::WindowFlags f = 0);
    ~PlayGLWidget();
//    void setMpvHandle(mpv::qt::Handle mh){mpv_h = mh;initMpvGL();}
//    void setMouseUsed(bool used);

private slots:
//    void swapped();

private:
//    double m_scale;
//    mpv::qt::Handle mpv_h;
//    mpv_opengl_cb_context *mpv_gl;
//    Mpv::PlayState m_state;
//    QTimer  *m_checkMouseTimer,
//            *m_lMouseClickTimer,
//            *m_fpsTimer;
//    bool    m_mouseUsed,
//            m_isMouseEnter,
//            hasVideo;

//    void initGlobalSig();
//    static void on_update(void *ctx);
//    void initMpvGL();

protected:
//    void initializeGL() override;
//    void paintGL() override;
//    void mousePressEvent(QMouseEvent *e) override;
//    void mouseMoveEvent(QMouseEvent *e) override;
//    void mouseDoubleClickEvent(QMouseEvent *e) override;
//    void enterEvent(QEvent *e) override;
//    void leaveEvent(QEvent *e) override;
};

#endif // PLAYGLWIDGET_H
