#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QWidget>
#include <QStackedWidget>

#include "core/mpvcore.h"

#define NormalModeSize   QSize(960, 540)
#define MiniModeSize    QSize(400, 225)

class HomePage;
class AboutDialog;
class ContralBar;
class PlayXWidget;
class PlayGLWidget;
class TitleMenu;
class SystemTrayIcon;
class KRightClickMenu;
class TitleWidget;
class MusicWidget;
class PlayListWidget;
class MiniModeShade;
class QDBusInterface;
class QLabel;

class MainWindow : public QWidget
{
    Q_OBJECT
    Q_CLASSINFO("D-Bus Interface", "org.ukui.kylinvideo.play")

public:
    explicit MainWindow(QStringList list, QWidget *parent = nullptr);
    ~MainWindow();

signals:

private:
    QStackedWidget  *m_stackedWidget;
    HomePage        *m_homePage;        // 主界面
    TitleMenu       *m_titleMenu;       // 标题栏菜单
    KRightClickMenu *m_rightClickMenu;  // 右键菜单
    TitleWidget     *m_titleWidget;     // 标题栏
    ContralBar      *m_contralBar;      // 控制栏
    MusicWidget     *m_musicWidget;     // 音乐播放界面
    PlayListWidget  *m_playListWidget;  // 播放列表界面
    SystemTrayIcon  *m_trayIcon;
    AboutDialog     *m_aboutDialog;

    QString m_currentFile;

    MiniModeShade   *m_miniModeShade;   // mini 模式遮罩
    QWidget *m_playWidget;

    QRect m_normalRect;

    Mpv::FileInfo       m_fileInfo;
    Mpv::PlayState      m_playStateForS34;
    Mpv::VideoAspect    m_vAspect;      // 视频比例
    MpvCore *m_core;

    bool m_isActive;
    bool m_exitFlag;
    bool m_isMiniMode;
    bool m_isMaxWindow;
    bool m_isFullScreen;
    bool m_canHideAll;
    bool m_needPlayWhenMin;
    bool m_needPlayWhenS34;
    bool m_isScreenLocked;

    QDBusInterface *m_dbusInterface;
    quint32 m_inhibitValue;             // 阻止锁屏cookie
    quint64 m_windowId;

public slots:
    void kylin_video_play_request(QStringList filelist);

private slots:
    // s3 s4 处理
    void onPrepareForSleep(bool isSleep);
    void onPrepareForShutdown(bool Shutdown);
    void onScreenLock();
    void onScreenUnlock();
    void onWiredControl(QString data);
    void slotPrepareForSwitchuser();

    // 耳机插拔
    void inputDeviceGet(QString device);

    void slotQuit();
    void slotClose();
    void slotShowMiniMode();
    void slotShowNormalMode();
    void slotShowFullScreen(bool);
    void slotShowTitleMenu();
    void slotChangeMaxState();
    void slotChangeMiniState();
    void slotOpenHelpDoc();

    void slotPlayStateChange();

    void slotThemeChange(int theme);
    void slotShowDefault();
    void slotChangePause();
    void slotOpenFile();
    void slotOpenDir();
    void slotPlayFile(QString file, int pos);
    void slotPlayWidgetClicked();
    void slotToTop(bool is_top = true);

private:
    void initGlobalSig();
    void initLayout();
    void initDBus();
    void initMenu();
    void initCore();

    void initTrayIcon();
    void initTitleWidget();
    void initPlayListWidget();
    void initMiniModeShade();
    void initContralBar();
    void initAboutDialog();

    void updateAspect();
    void resetLayout();
    void hideAll(bool);
    void appQuit();

    void Single(QStringList filelist);

    bool event(QEvent *event) override;
    void enterEvent(QEvent *event) override;
    void moveEvent(QMoveEvent *event) override;
    void resizeEvent(QResizeEvent *event) override;
    void closeEvent(QCloseEvent *event) override;
    void mousePressEvent(QMouseEvent *event) override;

    // 以下实现文件拖入播放
    void dragEnterEvent(QDragEnterEvent *event) override;
    void dropEvent(QDropEvent *event) override;
};

#endif // MAINWINDOW_H
