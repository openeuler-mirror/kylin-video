#include "mainwindow.h"

#include <QEvent>
#include <QTimer>
#include <QWindow>
#include <QThread>
#include <QMimeData>
#include <QDBusReply>
#include <QApplication>
#include <QDesktopWidget>
#include <QDBusInterface>
#include <QStandardPaths>
#include <QSystemTrayIcon>
#include <QDBusConnection>
#include <QFileSystemWatcher>
#include <QWindowStateChangeEvent>

#include <KF5/KWindowSystem/kwindowsystem.h>
#include <KWindowEffects>

//#include <windowmanager/windowmanager.h>
//#include <ukuistylehelper/ukuistylehelper.h>

#include "core/dbusadapter.h"

#include "widget/kmenu.h"
#include "widget/homepage.h"
#include "widget/contralbar.h"
#include "widget/aboutdialog.h"
#include "widget/musicwidget.h"
#include "widget/titlewidget.h"
#include "widget/playxwidget.h"
#include "widget/playglwidget.h"
#include "widget/xatom-helper.h"
#include "widget/minimodeshade.h"
#include "widget/systemtrayicon.h"
#include "widget/playlistwidget.h"
#include "widget/mediainfodialog.h"
#include "widget/setup/setupdialog.h"
#include "widget/ukui-wayland/plasma-shell-manager.h"
#include "widget/ukui-wayland/ukui-decoration-manager.h"

#include "global/global.h"
#include "global/functions.h"
#include "global/translator.h"
#include "global/extensions.h"

#include <ukui-log4qt.h>
#include <fcntl.h>

#include <X11/Xlib.h>
#include <QX11Info>

using namespace Global;

MainWindow::MainWindow(QStringList list, QWidget *parent) :
    QWidget(parent),
    m_windowId(0),
    m_exitFlag(false),
    m_isMiniMode(false),
    m_isMaxWindow(false),
    m_isFullScreen(false),
    m_stackedWidget(nullptr),
    m_homePage(nullptr),
    m_titleMenu(nullptr),
    m_titleWidget(nullptr),
    m_musicWidget(nullptr),
    m_playListWidget(nullptr),
    m_miniModeShade(nullptr)
{
    translator->load("");
    g_shortCut->setParent(this);
    g_shortCut->initData();

    connect(kdk::WindowManager::self(),&kdk::WindowManager::windowAdded,this,[=](const kdk::WindowId& windowId){
        if(getpid() == kdk::WindowManager::getPid(windowId))
        {
            m_windowId = windowId.toULongLong();
        }
    });

    initLayout();

    Single(list);
    initDBus();

    setAcceptDrops(true);

    initAboutDialog();
    initGlobalSig();
    initCore();
    initMenu();
    initTrayIcon();

    // 需要show出来之后才能播放，不然播放会失败，原因是 QOpenGLWidget 没有 show 的时候渲染会报错。
    QTimer::singleShot(1000, [list, this](){
        if(list.size() > 0)
            g_user_signal->addFiles(list);
        else {
            // 播放宣传片
            QString pf = QDir::homePath().append(tr("/Video")).append("/银河麒麟操作系统V10-sp1宣传视频.mp4");
            QFileInfo fi(pf);
            if (fi.exists())
                g_user_signal->addFiles(QStringList() << pf);
        }
    });
}

MainWindow::~MainWindow()
{

}

void MainWindow::kylin_video_play_request(QStringList filelist)
{
    // 此处相当于双击打开，需要active一下
    if (isHidden()) {
        if (Global::isWayland) {
            kdk::UkuiStyleHelper::self()->removeHeader(this);
            show();
        }
        else {
            show();
        }
    }
    else if (!isActiveWindow()) {
        // qt 的接口不好用，用kwin的接口
        KWindowSystem::forceActiveWindow(this->winId());
    }
    if (filelist.size() > 0)
        g_user_signal->addFiles(filelist);
}

void MainWindow::onPrepareForSleep(bool isSleep)
{
    if (isSleep) {
        // 进入睡眠停止播放，不然显示会有问题，共性问题，此方法规避
        m_playStateForS34 = g_playstate;
        if (g_playstate > 0) {
            if(g_config->keepStateWhenWakeup.first && g_playstate == Mpv::Playing)
                m_needPlayWhenS34 = true;
            m_core->Pause();
        }
    }
    else {
        m_core->Restart();
        if (m_needPlayWhenS34) {
            // 判断是否锁屏了，如果锁屏等解锁后再播放
            if(m_isScreenLocked)
                return;
            m_core->Play();
            m_needPlayWhenS34 = false;
        }
    }
    return;
}

void MainWindow::onPrepareForShutdown(bool Shutdown)
{
    if (Shutdown) {
        // 进入睡眠停止播放，不然显示会有问题，共性问题，此方法规避
        m_playStateForS34 = g_playstate;
        if (g_playstate > 0) {
            if(g_config->keepStateWhenWakeup.first && g_playstate == Mpv::Playing)
                m_needPlayWhenS34 = true;
            m_core->Pause();
        }
    }
    else {
        m_core->Restart();
        if (m_needPlayWhenS34) {
            // 判断是否锁屏了，如果锁屏等解锁后再播放
            if(m_isScreenLocked)
                return;
            m_core->Play();
            m_needPlayWhenS34 = false;
        }
    }
    return;
}

void MainWindow::onScreenLock()
{
    m_isScreenLocked = true;
    // 只有 wayland 才需要如此
    g_shortCut->makeAllInvalid();
    if(g_playstate == Mpv::Playing && m_needPlayWhenS34 == false)
    {
        m_core->Pause();
        if(g_config->keepStateWhenWakeup.first)
            m_needPlayWhenS34 = true;
    }
}

void MainWindow::onScreenUnlock()
{
    m_isScreenLocked = false;
    g_shortCut->makeAllValid();
    if(m_needPlayWhenS34)
    {
        m_core->Play();
        if(g_config->keepStateWhenWakeup.first)
            m_needPlayWhenS34 = false;
    }
}

void MainWindow::onWiredControl(QString data)
{
    int key = data.split(':').first().toInt();
    int num = data.split(':').last().toInt();
    if(num == 1)
        g_user_signal->play_pause();
    else if(num == 2 || key == 163)
        g_user_signal->playNext(true);
    else if(num == 3 || key == 165)
        g_user_signal->playPrev(true);
}

void MainWindow::slotPrepareForSwitchuser()
{
    if (m_core)
        m_core->Pause();
}

void MainWindow::inputDeviceGet(QString device)
{
    // 接收到耳机插拔信号就暂停
    KyInfo() << "playState : " << g_playstate << ", out device change " << device;
    if(g_playstate == Mpv::Playing) {
        m_core->Pause();
    }
}

void MainWindow::initLayout()
{
    if (isWayland) {
        kdk::UkuiStyleHelper::self()->removeHeader(this);
    }
    else
    {
        setProperty("useSystemStyleBlur", true);
        MotifWmHints hints1;
        hints1.flags = MWM_HINTS_FUNCTIONS | MWM_HINTS_DECORATIONS;
        hints1.functions = MWM_FUNC_ALL;
        hints1.decorations = MWM_DECOR_BORDER;
        XAtomHelper::getInstance()->setWindowMotifHint(winId(), hints1);
    }
    setMinimumSize(NormalModeSize);
    resize(NormalModeSize);

    KWindowEffects::enableBlurBehind(winId(), true);
    setWindowTitle(tr("Video Player"));
    setMouseTracking(true);

    m_stackedWidget = new QStackedWidget(this);
    m_homePage = new HomePage;

    if (g_config->hardwareType() == GlobalConfig::JMX200_VDPAU || g_config->hardwareType() == GlobalConfig::X100_GPU) {
        m_playWidget = new PlayXWidget;
        connect(dynamic_cast<PlayXWidget*>(m_playWidget), &PlayXWidget::mousePressed, this, &MainWindow::slotPlayWidgetClicked);
    }
    else {
        m_playWidget = new PlayGLWidget;
        connect(dynamic_cast<PlayGLWidget*>(m_playWidget), &PlayGLWidget::mousePressed, this, &MainWindow::slotPlayWidgetClicked);
    }

    m_stackedWidget->addWidget(m_homePage);
    m_stackedWidget->addWidget(m_playWidget);
    m_stackedWidget->setCurrentIndex(0);

    m_musicWidget = new MusicWidget(m_playWidget);
    connect(m_musicWidget, &MusicWidget::mousePressed, this, &MainWindow::slotPlayWidgetClicked);
    m_musicWidget->hide();

    initTitleWidget();
    initContralBar();
    initMiniModeShade();
    initPlayListWidget();
}

void MainWindow::initTrayIcon()
{
    m_trayIcon = new SystemTrayIcon(this);
    connect(m_trayIcon, &SystemTrayIcon::sigQuit, this, &MainWindow::appQuit);
    connect(m_trayIcon, &SystemTrayIcon::activated, [&](QSystemTrayIcon::ActivationReason reason){
        switch (reason) {
        case QSystemTrayIcon::Trigger:
            if (isHidden()) {
                show();
            }
            else if (!isActiveWindow()) {
                KWindowSystem::forceActiveWindow(winId());
            }
            else {
                // 点击的托盘图标的时候直接隐藏
                if (isFullScreen()) {
                    g_user_signal->fullScreen();
                }
                hide();
            }
            break;
        default:
            break;
        }
    });
    m_trayIcon->show();
}

void MainWindow::initDBus()
{
    m_dbusInterface = new QDBusInterface("org.gnome.SessionManager",
                                         "/org/gnome/SessionManager",
                                         "org.gnome.SessionManager",
                                         QDBusConnection::sessionBus());

    QDBusConnection sessionBus = QDBusConnection::sessionBus();
    if(sessionBus.registerService("org.ukui.kylinvideo"))
    {
        sessionBus.registerObject("/org/ukui/kylinvideo",this,
                                  QDBusConnection::ExportAllContents);
        KyInfo() << "初始化DBUS成功";
    }
    else
    {
        KyInfo("init dbus error");
    }
    //S3 S4策略
    QDBusConnection::systemBus().connect(QString("org.freedesktop.login1"),
                                         QString("/org/freedesktop/login1"),
                                         QString("org.freedesktop.login1.Manager"),
                                         QString("PrepareForShutdown"), this,
                                         SLOT(onPrepareForShutdown(bool)));
    QDBusConnection::systemBus().connect(QString("org.freedesktop.login1"),
                                         QString("/org/freedesktop/login1"),
                                         QString("org.freedesktop.login1.Manager"),
                                         QString("PrepareForSleep"), this,
                                         SLOT(onPrepareForSleep(bool)));

    // 锁屏
    QDBusConnection::sessionBus().connect(QString("org.ukui.ScreenSaver"),
                                         QString("/"),
                                         QString("org.ukui.ScreenSaver"),
                                         QString("lock"), this,
                                         SLOT(onScreenLock()));
    QDBusConnection::sessionBus().connect(QString("org.ukui.ScreenSaver"),
                                         QString("/"),
                                         QString("org.ukui.ScreenSaver"),
                                         QString("unlock"), this,
                                         SLOT(onScreenUnlock()));

    // 耳机插拔
    QDBusConnection::sessionBus().connect(QString(""),
                                         QString("/"),
                                         QString("org.ukui.media"),
                                         QString("sinkPortChanged"), this,
                                         SLOT(inputDeviceGet(QString)));

    // 线控
    QDBusConnection::systemBus().connect(QString(),
                                         QString("/"),
                                         QString("com.monitorkey.interface"),
                                         QString("monitorkey"), this,
                                         SLOT(onWiredControl(QString)));

    //切换用户
    QDBusConnection::sessionBus().connect(QString("org.gnome.SessionManager"),
                                          QString("/org/gnome/SessionManager"),
                                          QString("org.gnome.SessionManager"),
                                          QString("PrepareForSwitchuser"), this,
                                          SLOT(slotPrepareForSwitchuser()));

    DbusAdapter *dbs_adapter = new DbusAdapter;

}

void MainWindow::initMenu()
{
    m_rightClickMenu = new KRightClickMenu(this);

    connect(m_rightClickMenu, SIGNAL(sigOpenFile()), this, SLOT(slotOpenFile()));
    connect(m_rightClickMenu, SIGNAL(sigOpenDir()), this, SLOT(slotOpenDir()));
    connect(m_rightClickMenu, SIGNAL(sigOpenUrl()), this, SLOT(slotOpenUrl()));
    connect(m_rightClickMenu, SIGNAL(sigToTop(bool)), this, SLOT(slotToTop(bool)));
    connect(m_rightClickMenu, SIGNAL(sigPlayOrder(int)),this, SLOT(slotPlayOrder(int)));
    connect(m_rightClickMenu, &KRightClickMenu::sigDefaultFrame, [this](){
        m_vAspect = Mpv::AUTO;
    });
    connect(m_rightClickMenu, &KRightClickMenu::sig4Div3Frame, [this](){
        m_vAspect = Mpv::DIV_4_3;
    });
    connect(m_rightClickMenu, &KRightClickMenu::sig16Div9Frame, [this](){
        m_vAspect = Mpv::DIV_16_9;
    });
    connect(m_rightClickMenu, &KRightClickMenu::sigFullFrame, [this](){
        m_vAspect = Mpv::FULL;
//        updateAspect();
    });

    connect(m_rightClickMenu, &KRightClickMenu::sigRestoreFrame, [this](){
        m_vAspect = Mpv::AUTO;
    });

    connect(m_rightClickMenu, &KRightClickMenu::sigAlongRotate, [this](){
        // 旋转后需要判断是否时满屏画面，如果是的话需要改变比例
//        if(m_vAspect == Mpv::FULL)
//            updateAspect();
    });
    connect(m_rightClickMenu, &KRightClickMenu::sigInverseRotate, [this](){
//        if(m_vAspect == Mpv::FULL)
//            updateAspect();
    });
    connect(m_rightClickMenu, &KRightClickMenu::sigMediaInfo, [this](){
        if(g_playstate < 0)
            return;
        // 媒体信息弹窗
        MediaInfoDialog mi;
        mi.setModal(true);
        mi.setData(m_core->getMediaInfo());
        mi.setTitle(m_fileInfo.media_title);
        mi.setType(m_fileInfo.file_type);
        mi.setSize(m_fileInfo.file_size);
        mi.setDuration(Functions::timeToStr(m_fileInfo.length, false));
        mi.setPath(m_fileInfo.file_path);
//        mi.updateDate();
        connect(g_core_signal, &GlobalCoreSignal::sigFileInfoChange, &mi, [&mi, this](Mpv::FileInfo fi){
            m_fileInfo = fi;
            mi.setData(m_core->getMediaInfo());
            mi.setTitle(m_fileInfo.media_title);
            mi.setType(m_fileInfo.file_type);
            mi.setSize(m_fileInfo.file_size);
            mi.setDuration(Functions::timeToStr(m_fileInfo.length, false));
            mi.setPath(m_fileInfo.file_path);
//            mi.updateDate();
        });
        mi.move(geometry().center() - mi.geometry().center());
        if (isWayland) {
            kdk::UkuiStyleHelper::self()->removeHeader(&mi);
            mi.show();
            QPoint desktop_center = qApp->desktop()->geometry().center();
            QPoint about_center(mi.width()/2, mi.height()/2);
            QPoint center = desktop_center - about_center;
            kdk::WindowManager::setGeometry(mi.windowHandle(),
                                            QRect(center, QSize(mi.size())));
        }
        else {
            mi.show();
        }
        mi.exec();
    });
}

void MainWindow::initCore()
{
    m_core = new MpvCore(m_playWidget);
    connect(m_core, &MpvCore::sigShowText, m_musicWidget, &MusicWidget::showOsdText);
}

void MainWindow::initTitleWidget()
{
    m_titleMenu = new TitleMenu;
    connect(m_titleMenu, &TitleMenu::sigQuit, this, &MainWindow::slotQuit);

    m_titleWidget = new TitleWidget(this);
    m_titleWidget->raise();
    m_titleWidget->move(0, 0);
    m_titleWidget->setTitle(tr("Video Player"));

    connect(m_titleWidget, &TitleWidget::sigMaxSize,    this, &MainWindow::slotChangeMaxState);
    connect(m_titleWidget, &TitleWidget::sigMiniSize,   this, &MainWindow::slotChangeMiniState);
    connect(m_titleWidget, &TitleWidget::sigClose,      this, &MainWindow::slotClose);
    connect(m_titleWidget, &TitleWidget::sigShowMenu,   this, &MainWindow::slotShowTitleMenu);
    connect(m_titleWidget, &TitleWidget::sigMiniMode,   this, &MainWindow::slotShowMiniMode);
    connect(m_titleWidget, &TitleWidget::sigCanHide, [this](bool canHide){m_canHideAll = canHide;});
}

void MainWindow::initPlayListWidget()
{
    m_playListWidget = new PlayListWidget(this);
    m_playListWidget->raise();
    m_playListWidget->move(width()-16, 0);

    // 标题栏跟随列表展开改变大小
    connect(m_playListWidget, &PlayListWidget::sigMove, this, [this](int distance){
        m_titleWidget->setGeometry(0, 0, width() - distance, m_titleWidget->height());
    });

    // 列表显示的时候隐藏标题栏和控制栏
    connect(g_user_signal, &GlobalUserSignal::sigShowPlayList, [&](){
        if(m_stackedWidget->currentIndex() == 1) {
            // 防止列表弹出的时候鼠标在播放界面上移动导致标题栏和控制栏弹出
            m_playWidget->setMouseTracking(false);
            QTimer::singleShot(400, [this](){m_playWidget->setMouseTracking(true);});

            m_canHideAll = true;
            hideAll(true);
        }
    });

    // 正在播放的文件改变，书签需要刷新
    connect(m_playListWidget->getPlayList(), &PlayList::sigPlayingFileMarkUpdate, [this](QVector<MarkItem> marks){
        m_contralBar->clearMark();
        foreach (MarkItem item, marks) {
            m_contralBar->addMark(item.m_markPos, item.m_describe);
        }
        m_contralBar->updateMarks();
    });

    connect(m_playListWidget->getPlayList(), &PlayList::sigDeleteMark, [this](int mark_pos){
        m_contralBar->deleteMark(mark_pos);
    });

    // 正在播放时插入书签，需要刷新进度条书签
    connect(m_playListWidget->getPlayList(), &PlayList::sigInsertMark, [this](MarkItem mark){
        m_contralBar->insertMark(mark.m_markPos, mark.m_describe);
    });
}

void MainWindow::initMiniModeShade()
{
    if (g_config->hardwareType() == GlobalConfig::JMX200_VDPAU || g_config->hardwareType() == GlobalConfig::X100_GPU)
        return;
    m_miniModeShade = new MiniModeShade(this);
    m_miniModeShade->hide();

    connect(m_miniModeShade, &MiniModeShade::sigClose,      this, &MainWindow::close);
    connect(m_miniModeShade, &MiniModeShade::sigShowNormal, this, &MainWindow::slotShowNormalMode);
    connect(m_miniModeShade, &MiniModeShade::sigPlayPause, [&](){
        g_user_signal->sigPlayPause();
    });
}

void MainWindow::initContralBar()
{
    m_contralBar = new ContralBar(this);
    m_contralBar->hide();
    m_contralBar->raise();

    connect(m_contralBar, &ContralBar::sigFullScreen, this, &MainWindow::slotShowFullScreen);
    connect(m_contralBar, &ContralBar::sigCanHide, [this](bool canHide){m_canHideAll = canHide;});
}

void MainWindow::initAboutDialog()
{
    m_aboutDialog = new AboutDialog;
    m_aboutDialog->hide();
}

void MainWindow::updateAspect()
{
    double s;
    if(m_core->getRotate() / 90 % 2 == 0)
        s = (double)width() / (double)height();
    else
        s = (double)height() / (double)width();
    m_core->SetAspect(QString::number(s));
}

void MainWindow::resetLayout()
{
    if (!m_isMiniMode && !m_isMaxWindow && !m_isFullScreen)
        m_normalRect = geometry();

    m_titleWidget->setGeometry(0, 0, width(), m_titleWidget->height());
    m_contralBar->setGeometry(120, height()-72, width()-240, 48);
    m_contralBar->setPreviewSize(size());

    m_musicWidget->setGeometry(0, 0, width(), height());
    m_playWidget->setGeometry(0, 0, width(), height());
    m_stackedWidget->setGeometry(0, 0, width(), height());

    m_playListWidget->updateHideIcon();
    m_playListWidget->move(width() - 16, 0);
    m_playListWidget->resize(m_playListWidget->width(), height());

    m_titleWidget->raise();

    if (m_stackedWidget->currentIndex() == 1)
        hideAll(true);

    if (m_miniModeShade)
        m_miniModeShade->resize(size());
}

void MainWindow::hideAll(bool hide)
{
    if (m_stackedWidget->currentIndex() == 0)
        return;
    if (hide)
    {
        if(m_canHideAll)
        {
            m_contralBar->setHide();
            m_titleWidget->setHide();
            if (!m_playListWidget->isShow())
                m_playListWidget->setShowButton(false);
            // 播放列表是否需要隐藏 ?
        }
        else
        {
            // 鼠标要显示出来
            setCursor(Qt::ArrowCursor);
            m_playWidget->setCursor(Qt::ArrowCursor);
            m_titleWidget->setCursor(Qt::ArrowCursor);
        }
    }
    else
    {
        if (!m_playListWidget->isShow()) {
            if (m_stackedWidget->currentIndex() == 1)
                m_contralBar->setShow();
            m_titleWidget->setShow();
            if (!m_isMiniMode)
                m_playListWidget->setShowButton(true);
        }
    }
}

void MainWindow::appQuit()
{
    // 判断退出时是否需要清空播放列表
    if(g_config->clearListWhenExit.first)
        g_user_signal->clearPlayList();
    m_exitFlag = true;
    if (g_playstate < 0) {
        exit(0);
    }
    m_core->Stop();
}

void MainWindow::Single(QStringList filelist)
{
    QStringList homePath = QStandardPaths::standardLocations(QStandardPaths::HomeLocation);
    QString lockPath = homePath.at(0) + "/.config/kylin-video-lock";
    int fd = open(lockPath.toUtf8().data(), O_WRONLY | O_CREAT | O_TRUNC, S_IRUSR | S_IWUSR);

    if (fd < 0) { exit(1); }
    if (lockf(fd, F_TLOCK, 0))
    {
        QDBusInterface interface( "org.ukui.kylinvideo",
                                  "/org/ukui/kylinvideo",
                                  "org.ukui.kylinvideo.play",
                                  QDBusConnection::sessionBus());
        QDBusReply<int> reply = interface.call( "kylin_video_play_request", filelist);
        qDebug() << "file path is " << filelist;
        if ( reply.isValid() && reply.value() == 0)
        {
            KyInfo() << "call kylin_video_play_request ok";
        }
        else
        {
            KyInfo() << "fail";
        }
        KyInfo("The app is already running");
        exit(0);
    }
}

void MainWindow::slotQuit()
{
    if(g_config->clearListWhenExit.first)
        g_user_signal->clearPlayList();
    m_exitFlag = true;
    if (g_playstate < 0) {
        exit(0);
    }
    m_core->Stop();
}

void MainWindow::slotClose()
{
    resetLayout();
    close();
}

void MainWindow::slotShowMiniMode()
{
    if (m_isMiniMode || isFullScreen())
        return;

    if (m_isMaxWindow) {
        showNormal();
        m_isMaxWindow = false;
        m_titleWidget->updateMaxButtonStatus(false);
    }

    m_isMiniMode = true;
    m_contralBar->setMiniMode(true);
    m_titleWidget->setMiniMode(true);
    m_titleWidget->hide();
    m_contralBar->hide();
    m_playListWidget->hide();

    QTimer::singleShot(20, [this](){
        setMinimumSize(MiniModeSize);
        resize(MiniModeSize);
        if (g_config->hardwareType() == GlobalConfig::JMX200_VDPAU || g_config->hardwareType() == GlobalConfig::X100_GPU)
            dynamic_cast<PlayXWidget*>(m_playWidget)->setMouseUsed(false);
        else
            dynamic_cast<PlayGLWidget*>(m_playWidget)->setMouseUsed(false);
        if (m_miniModeShade) {
            m_miniModeShade->show();
            m_miniModeShade->raise();
        }
    });
}

void MainWindow::slotShowNormalMode()
{
    if (!m_isMiniMode)
        return;
    setMinimumSize(NormalModeSize);
    setMaximumSize(99999, 99999);
    setGeometry(m_normalRect);

    m_contralBar->setMiniMode(false);
    m_titleWidget->setMiniMode(false);
    m_playListWidget->show();

    if (g_config->hardwareType() == GlobalConfig::JMX200_VDPAU || g_config->hardwareType() == GlobalConfig::X100_GPU)
        dynamic_cast<PlayXWidget*>(m_playWidget)->setMouseUsed(true);
    else
        dynamic_cast<PlayGLWidget*>(m_playWidget)->setMouseUsed(true);

    if (m_miniModeShade)
        m_miniModeShade->hide();

    m_isMiniMode = false;
}

void MainWindow::slotShowFullScreen(bool full)
{
    if (m_isFullScreen == full)
        return;
    if (m_isMiniMode)
        return;
    if (full)
    {
        m_isFullScreen = true;
        if (isWayland) {
            setWindowState(windowState() | Qt::WindowFullScreen);
        }
        else {
            KWindowSystem::setState(winId(), NET::FullScreen);
        }
        m_titleWidget->setButtonState(false);
    }
    else
    {
        if (isWayland) {
            setWindowState(windowState() & ~Qt::WindowFullScreen);
        }
        else {
            KWindowSystem::clearState(winId(), NET::FullScreen);
        }
        m_titleWidget->setButtonState(true);
        m_isFullScreen = false;
    }
    m_canHideAll = true;
    hideAll(true);
}

void MainWindow::slotShowTitleMenu()
{
    m_titleMenu->exec(QPoint(m_titleWidget->getMenuBtnX()+mapToGlobal(QPoint(0,0)).x(),
                             mapToGlobal(QPoint(0,0)).y()+m_titleWidget->height()-5));
}

void MainWindow::slotChangeMaxState()
{
    if (windowState() & Qt::WindowMaximized) {
        showNormal();
        m_isMaxWindow = false;
    }
    else {
        showMaximized();
        m_isMaxWindow = true;
    }
}

void MainWindow::slotChangeMiniState()
{
    if (!(windowState() & Qt::WindowMinimized))
        showMinimized();
}

void MainWindow::slotOpenHelpDoc()
{
    // 帮助手册 先就分开写吧，快捷键不生效不知道为啥
    QDBusMessage m = QDBusMessage::createMethodCall("com.kylinUserGuide.hotel_1000",
                                                    "/",
                                                    "com.guide.hotel",
                                                    "showGuide");
    m << "kylin-video";
    if(QDBusConnection::sessionBus().isConnected())
        QDBusConnection::sessionBus().call(m);
}

void MainWindow::slotPlayStateChange()
{
    if(g_playstate > 0) {
        m_stackedWidget->setCurrentIndex(1);
//        m_stackedWidget->setCurrentWidget(m_playWidget);
        m_titleWidget->setHomePage(false);
    }

    // 停止之后画面比例还原（如果需要保持比例需要重新做功能）
    if (g_playstate < 0) {
        m_vAspect = Mpv::AUTO;
    }

    if(g_playstate == Mpv::Playing || g_playstate == Mpv::Paused)
    {
        if(m_core->getVid() >= 0) {
            m_musicWidget->hide();
        }
        else {
            m_musicWidget->show();
            m_musicWidget->setCursor(Qt::ArrowCursor);
            m_musicWidget->raise();
        }
    }
    else {
        m_musicWidget->hide();
    }

    // 如果正在播放，阻止锁屏
    if (m_dbusInterface->isValid()) {
        if (g_playstate == Mpv::Playing)
        {
            QDBusMessage reply = m_dbusInterface->call(QDBus::Block, "Inhibit", "kylin-video", (quint32)0, "video is playing", (quint32)8);
            m_inhibitValue = reply.arguments().takeFirst().toUInt();
        }
        else
        {
            m_dbusInterface->call("Uninhibit", m_inhibitValue);
        }
    }
    else {
        KyInfo("org.gnome.SessionManager is invalid!");
    }

    // 停止后是否需要退出
    if (g_playstate == Mpv::Idle && m_exitFlag) {
        exit(0);
    }
}

void MainWindow::slotThemeChange(int theme)
{
    switch (theme) {
    case 0:
        g_settings->setValue("General/follow_system_theme", true);
        break;
    case 1:
        g_settings->setValue("General/follow_system_theme", false);
        g_settings->setValue("General/theme", 0);
        break;
    case 2:
        g_settings->setValue("General/follow_system_theme", false);
        g_settings->setValue("General/theme", 1);
        break;
    default:
        break;
    }
}

void MainWindow::slotShowDefault()
{
    // 当前默认为拼音拼播放界面
    m_musicWidget->hide();
    m_titleWidget->setTitle(tr("Video Player"));
    m_titleWidget->setShow();
    hideAll(false);
    m_contralBar->hide();
    m_stackedWidget->setCurrentIndex(0);
    m_titleWidget->setHomePage(true);
}

void MainWindow::slotChangePause()
{
    if(m_playListWidget->isShow())
        m_playListWidget->slotHide();

    if(g_playstate == Mpv::Playing)
        m_core->Pause();
    else if(g_playstate == Mpv::Paused)
        m_core->Play();
}

/**
 * @brief       : 打开文件
 * @param [in]  :
 * @param [out] :
 * @return      :
 */
void MainWindow::slotOpenFile()
{
    Extensions e;
    QString last_path = g_settings->value("History/last_path").toString();
    if(last_path == "")
        last_path = QDir::homePath();
    QStringList files;
    {
        QFileDialog fd(this);
        fd.setModal(true);
        QList<QUrl> list = fd.sidebarUrls();
        int sidebarNum = 8;
        QString home = QDir::homePath().section("/", -1, -1);
        QString mnt = "/media/" + home + "/";
        QDir mntDir(mnt);
        mntDir.setFilter(QDir::Dirs | QDir::NoDotAndDotDot);
        QFileInfoList filist = mntDir.entryInfoList();
        QList<QUrl> mntUrlList;
        for(int i=0; i < sidebarNum && i < filist.size(); i++) {
            QFileInfo fi = filist.at(i);
            //华为990、9a0需要屏蔽最小系统挂载的目录
            if (fi.fileName() == "2691-6AB8")
                 continue;
            mntUrlList << QUrl("file://" + fi.filePath());
        }
        QFileSystemWatcher fsw(&fd);
        fsw.addPath("/media/" + home + "/");
        connect(&fsw, &QFileSystemWatcher::directoryChanged, &fd, [=, &sidebarNum, &mntUrlList, &list, &fd](const QString path){
            QDir wmn_dir(path);
            wmn_dir.setFilter(QDir::Dirs | QDir::NoDotAndDotDot);
            QFileInfoList wfilist = wmn_dir.entryInfoList();
            mntUrlList.clear();
            for(int i=0; i < sidebarNum && i < wfilist.size(); ++i) {
                QFileInfo fi = wfilist.at(i);
                //华为990、9a0需要屏蔽最小系统挂载的目录
                if (fi.fileName() == "2691-6AB8")
                     continue;
                mntUrlList << QUrl("file://" + fi.filePath());
            }
            fd.setSidebarUrls(list + mntUrlList);
            fd.update();
        });
        connect(&fd, &QFileDialog::finished, &fd, [=, &list, &fd](){
            fd.setSidebarUrls(list);
        });
        fd.setSidebarUrls(list + mntUrlList);
        fd.setDirectory(QDir(last_path));
        fd.setWindowTitle(tr("Video Player Choose a file"));

        QString setFilterM = tr("Multimedia") + (" (%1) ");
        setFilterM = setFilterM.arg(e.allPlayable().forFilter());

        QString setFilterV = tr("Video") + (" (%1) ");
        setFilterV = setFilterV.arg(e.video().forFilter());

        QString setFilterA = tr("Audio") + (" (%1) ");
        setFilterA = setFilterA.arg(e.audio().forFilter());

        fd.setNameFilters(QStringList()
                          << setFilterM
                          << setFilterV
                          << setFilterA);

        fd.setFileMode(QFileDialog::ExistingFiles);
        fd.setViewMode(QFileDialog::Detail);
        fd.setOption(QFileDialog::HideNameFilterDetails);

        g_shortCut->makeAllInvalid();
        if(fd.exec() == QFileDialog::Accepted)
        {
            files = fd.selectedFiles();
            qDebug() << files;
        }
        g_shortCut->makeAllValid();
    }

    if(files.size() <= 0)
        return;
    g_settings->setValue("History/last_path", files.first().left(files.first().lastIndexOf('/') + 1));

    g_user_signal->addFiles(files);
}

void MainWindow::slotOpenDir()
{
    QString last_path = g_settings->value("History/last_path").toString();
    // 打开文件夹
    QString url;
    {
        QFileDialog fd(this);
        fd.setModal(true);
        int sidebarNum = 8;
        QList<QUrl> list = fd.sidebarUrls();
        QString home = QDir::homePath().section("/", -1, -1);
        QString mnt = "/media/" + home + "/";
        QDir mntDir(mnt);
        mntDir.setFilter(QDir::Dirs | QDir::NoDotAndDotDot);
        QFileInfoList filist = mntDir.entryInfoList();
        QList<QUrl> mntUrlList;
        for(int i=0; i < sidebarNum && i < filist.size(); i++) {
            QFileInfo fi = filist.at(i);
            //华为990、9a0需要屏蔽最小系统挂载的目录
            if (fi.fileName() == "2691-6AB8")
                 continue;
            mntUrlList << QUrl("file://" + fi.filePath());
        }
        QFileSystemWatcher fsw(&fd);
        fsw.addPath("/media/" + home + "/");
        connect(&fsw, &QFileSystemWatcher::directoryChanged, &fd, [=, &sidebarNum, &mntUrlList, &list, &fd](const QString path){
            QDir wmnDir(path);
            wmnDir.setFilter(QDir::Dirs | QDir::NoDotAndDotDot);
            QFileInfoList wfilist = wmnDir.entryInfoList();
            mntUrlList.clear();
            for(int i=0; i < sidebarNum && i < wfilist.size(); ++i) {
                QFileInfo fi = wfilist.at(i);
                //华为990、9a0需要屏蔽最小系统挂载的目录
                if (fi.fileName() == "2691-6AB8")
                     continue;
                mntUrlList << QUrl("file://" + fi.filePath());
            }
            fd.setSidebarUrls(list + mntUrlList);
            fd.update();
        });
        connect(&fd, &QFileDialog::finished, &fd, [=, &list, &fd](){
            fd.setSidebarUrls(list);
        });
        fd.setSidebarUrls(list + mntUrlList);
        fd.setDirectory(QDir(last_path));
        fd.setWindowTitle(tr("Video Player Choose a directory"));
        fd.setFileMode(QFileDialog::DirectoryOnly);

        g_shortCut->makeAllInvalid();
        if(fd.exec() == QFileDialog::Accepted)
        {
            url = fd.selectedUrls().at(0).toString();
            if(url.startsWith("file")) {
                url.remove(0, 7);
            }
        }
        g_shortCut->makeAllValid();
    }

    if (!url.isEmpty()) {
        g_user_signal->addDir(url);
    }
    g_settings->setValue("History/last_path", url);
}

void MainWindow::slotPlayFile(QString file, int pos)
{
    if (file == "")
        return;

    m_stackedWidget->setCurrentIndex(1);
//    m_stackedWidget->setCurrentWidget(m_playWidget);
    m_titleWidget->setHomePage(false);
    m_core->Open(file, pos);
}

void MainWindow::slotPlayWidgetClicked()
{
#if 0
    if(m_playListWidget->isShow())
        m_playListWidget->slotHide();
    else
#endif
    {
        if(m_playListWidget->isShow()) {
            m_playListWidget->slotHide();
        }
        else {
            if(g_playstate == Mpv::Playing)
                m_core->Pause();
            else if(g_playstate == Mpv::Paused)
                m_core->Play();
        }
    }
}

void MainWindow::slotToTop(bool isTop)
{
    if(!isWayland)
    {
        Display *display = QX11Info::display();
        XEvent event;
        event.xclient.type = ClientMessage;
        event.xclient.serial = 0;
        event.xclient.send_event = True;
        event.xclient.display = display;
        event.xclient.window  = winId();
        event.xclient.message_type = XInternAtom (display, "_NET_WM_STATE", False);
        event.xclient.format = 32;

        event.xclient.data.l[0] = isTop;
        event.xclient.data.l[1] = XInternAtom (display, "_NET_WM_STATE_ABOVE", False);
        event.xclient.data.l[2] = 0; //unused.
        event.xclient.data.l[3] = 0;
        event.xclient.data.l[4] = 0;

        XSendEvent(display, DefaultRootWindow(display), False,
                   SubstructureRedirectMask|SubstructureNotifyMask, &event);
    }
    else
    {
        if (kdk::WindowManager::getwindowInfo(m_windowId).isKeepAbove() != isTop)
            kdk::WindowManager::keepWindowAbove(m_windowId);
    }
}

void MainWindow::initGlobalSig()
{
    connect(g_user_signal, &GlobalUserSignal::sigShowStopFrame,     this, &MainWindow::slotShowDefault);
    connect(g_user_signal, &GlobalUserSignal::sigExit,              this, &MainWindow::close);
    connect(g_user_signal, &GlobalUserSignal::sigPlayWidgetClicked, this, &MainWindow::slotChangePause);
    connect(g_user_signal, &GlobalUserSignal::sigSelectFile,        this, &MainWindow::slotOpenFile);
    connect(g_user_signal, &GlobalUserSignal::sigSelectDir,         this, &MainWindow::slotOpenDir);
    // 直接让 mpvcore 去播放有问题，必须先切换到播放页面
    connect(g_user_signal, &GlobalUserSignal::sigOpen,              this, &MainWindow::slotPlayFile);

    connect(g_user_signal, &GlobalUserSignal::sigPlayPause, [&](){
        if(g_playstate == Mpv::Playing)
            m_core->Pause();
        else if(g_playstate == Mpv::Paused)
            m_core->Play();
    });

    connect(g_user_signal, &GlobalUserSignal::sigOpenHelpDoc,   this, &MainWindow::slotOpenHelpDoc);
    connect(g_user_signal, &GlobalUserSignal::sigHideBar,       this, &MainWindow::hideAll);
    connect(g_core_signal, &GlobalCoreSignal::sigStateChange,   this, &MainWindow::slotPlayStateChange);
    connect(g_core_signal, &GlobalCoreSignal::sigFileInfoChange, [&](Mpv::FileInfo fi){
        int tmp_duration = m_fileInfo.length;
        m_fileInfo = fi;
        m_fileInfo.length = tmp_duration;
        m_currentFile = fi.file_path;
        m_titleWidget->setTitle(fi.file_path.split("/").back());
    });

    connect(g_user_signal, &GlobalUserSignal::sigChangeShowMode, [this](){
        if (m_stackedWidget->currentIndex() == 0)
            return;
        if (m_isMiniMode)
            slotShowNormalMode();
        else
            slotShowMiniMode();
    });

    // ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

#if 1
    connect(g_user_signal, &GlobalUserSignal::sigTheme, this, &MainWindow::slotThemeChange);
#endif

    connect(g_user_signal, &GlobalUserSignal::sigRightMenuShow, [&](){
#if 0
        // 华为机器才需要这个
        if(!m_isActive && isWayland)
            return;
#endif
        if (QGuiApplication::focusWindow()) {
            if (g_config->hardwareType() == GlobalConfig::JMX200_VDPAU ||
                g_config->hardwareType() == GlobalConfig::X100_GPU)
                dynamic_cast<PlayXWidget*>(m_playWidget)->setMouseEnter(false);
            else
                dynamic_cast<PlayGLWidget*>(m_playWidget)->setMouseEnter(false);
            m_rightClickMenu->exec(QCursor::pos(QGuiApplication::focusWindow()->screen()) + QPoint(1,1));
        }
    });

#if 0
    connect(g_user_signal, &GlobalUserSignal::sigShowPlayList, [&](){
        if(!m_playListWidget->isShow() && ui->stackedWidget->currentIndex() == 1) {
            slotHideAll(true);
        }
    });
#endif

    connect(g_core_signal, &GlobalCoreSignal::sigDuration, [&](QString, double duration){
        m_fileInfo.length = (int)duration;
    });

    connect(g_user_signal, &GlobalUserSignal::sigShowSetup, [&](int index){
        SetUpDialog setup(this);
        setup.setModal(true);
        setup.setIndex(index);
        setup.move(geometry().center() - setup.geometry().center());

        if (isWayland)
        {
            kdk::UkuiStyleHelper::self()->removeHeader(&setup);
            setup.show();
            QPoint desktop_center = qApp->desktop()->geometry().center();
            QPoint about_center(setup.width()/2, setup.height()/2);
            QPoint center = desktop_center - about_center;
            kdk::WindowManager::setGeometry(setup.windowHandle(),
                                            QRect(center, QSize(setup.size())));
        }
        else {
            setup.show();
        }
        setup.exec();
    });

    connect(g_user_signal, &GlobalUserSignal::sigShowAbout, [&](){
        AboutDialog aboutDialog(this);
        aboutDialog.setModal(true);
        aboutDialog.move(this->geometry().center() - aboutDialog.geometry().center());

        if (isWayland)
        {
            kdk::UkuiStyleHelper::self()->removeHeader(&aboutDialog);
            aboutDialog.show();
            QPoint desktop_center = qApp->desktop()->geometry().center();
            QPoint about_center(aboutDialog.width()/2, aboutDialog.height()/2);
            QPoint center = desktop_center - about_center;
            kdk::WindowManager::setGeometry(aboutDialog.windowHandle(),
                                            QRect(center, QSize(aboutDialog.size())));
        }
        else {
            aboutDialog.show();
        }
        aboutDialog.exec();
    });
}

bool MainWindow::event(QEvent *event)
{
    switch (event->type()) {
    case QEvent::WindowStateChange:
        if (windowState() & Qt::WindowMaximized)
            m_titleWidget->updateMaxButtonStatus(true);
        else
            m_titleWidget->updateMaxButtonStatus(false);
        break;
    case QEvent::ContextMenu:
        // 主界面也能右键呼出菜单
        if (QGuiApplication::focusWindow()) {
            g_user_signal->showRightMenu();
        }
    case QEvent::MouseMove:
        setCursor(Qt::ArrowCursor);
    default:
        break;
    }

    if (event->type() == QEvent::Show && m_needPlayWhenMin) {
        m_core->Play();
        m_needPlayWhenMin = false;
    }

    if(event->type() == QEvent::Hide && g_config->pauseWhenMini.first && g_playstate == Mpv::Playing) {
        m_core->Pause();
        m_needPlayWhenMin = true;
    }

    return QWidget::event(event);
}

void MainWindow::enterEvent(QEvent *event)
{
    hideAll(false);
    return QWidget::enterEvent(event);
}

void MainWindow::moveEvent(QMoveEvent *event)
{
    if (!m_isMiniMode && !m_isMaxWindow && !m_isFullScreen)
        m_normalRect = geometry();
}

void MainWindow::resizeEvent(QResizeEvent *event)
{
    resetLayout();
    return QWidget::resizeEvent(event);
}

void MainWindow::closeEvent(QCloseEvent *event)
{
    // 关闭的时候最小化到系统托盘 就是隐藏了就行
    if(g_config->miniToTray.first)
    {
        // 隐藏的时候有必要还原大小，不然再次显示会有问题
        if (isFullScreen()) {
            g_user_signal->fullScreen();
        }

        event->ignore();
        hide();
        return;
    }

    // 判断退出时是否需要清空播放列表
    if(g_config->clearListWhenExit.first)
        g_user_signal->clearPlayList();
    m_core->Stop();
    QThread::usleep(100000);

    // 关闭之前取消阻止锁屏
    m_dbusInterface->call("Uninhibit", m_inhibitValue);
    QWidget::closeEvent(event);
    exit(0);
}

void MainWindow::mousePressEvent(QMouseEvent *event)
{
#if 0
    if (event->button() == Qt::LeftButton) {
        m_pressPos = event->pos();
        m_isMove = true;
    }else
#endif

    return QWidget::mousePressEvent(event);
}

void MainWindow::dragEnterEvent(QDragEnterEvent *event)
{
    event->acceptProposedAction();
}

void MainWindow::dropEvent(QDropEvent *event)
{
    QList<QUrl> listUrl = event->mimeData()->urls();
    QStringList filelist;
    Extensions e;
    QRegExp rx_video(e.video().forRegExp());
    QRegExp rx_audio(e.audio().forRegExp());
    rx_video.setCaseSensitivity(Qt::CaseInsensitive);
    rx_audio.setCaseSensitivity(Qt::CaseInsensitive);
    for (QUrl url : listUrl)
    {
        QString path = url.path();

        // 不要 file:// 前缀只要绝对路径
        if(path.startsWith("file:"))
            path.remove(0, 7);

        // 拖入文件需要做类型判断
        QFileInfo fi(path);
        if (fi.isDir()) {
            // 如果是文件夹的话添加文件夹
            g_user_signal->addDir(path);
        }
        else if (rx_video.indexIn(fi.suffix()) > -1 || rx_audio.indexIn(fi.suffix()) > -1) {
            filelist << path;
        }
    }
    if(filelist.count() == 0) {
        return;
    }
    g_user_signal->addFiles(filelist);
}
