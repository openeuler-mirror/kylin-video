#include "testwidget.h"

#include <QPushButton>
#include <QFileDialog>

#include "global/global.h"

TestWidget::TestWidget(QWidget *parent) : QWidget(parent)
{
    Global::global_init();

    gl_w = new PlayGLWidget(this);
    m_core = new MpvCore(gl_w);

    QPushButton *button = new QPushButton(nullptr);
    button->show();
    connect(button, &QPushButton::clicked, [this](){
        QString file = QFileDialog::getOpenFileName();
        m_core->Open(file);
    });
}
