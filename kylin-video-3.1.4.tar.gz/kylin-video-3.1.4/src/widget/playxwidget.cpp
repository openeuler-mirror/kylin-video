#include "playxwidget.h"

PlayXWidget::PlayXWidget(QWidget *parent) :
    EventPassWidget(parent)
{

}

PlayXWidget::~PlayXWidget()
{

}
