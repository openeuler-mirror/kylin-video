#include "playglwidget.h"

#include <QGSettings>

#include <ukui-log4qt.h>

#include "global/global.h"

using namespace Global;

static void *get_proc_address(void *ctx, const char *name) {
    Q_UNUSED(ctx);
    QOpenGLContext *glctx = QOpenGLContext::currentContext();
    if (!glctx)
        return NULL;
    return (void *)glctx->getProcAddress(QByteArray(name));
}

PlayGLWidget::PlayGLWidget(QWidget *parent)
    : QOpenGLWidget(parent)
{
    setlocale(LC_NUMERIC, "C");
    setMouseTracking(true);
}

PlayGLWidget::~PlayGLWidget()
{

}

void PlayGLWidget::setMpvHandle(mpv::qt::Handle _handle)
{
    m_mpvHandle = _handle;
    initMpvGL();
}

void PlayGLWidget::swapped()
{
    mpv_opengl_cb_report_flip(m_mpvCallBack, 0);
}

void PlayGLWidget::on_update(void *ctx)
{
    QMetaObject::invokeMethod((PlayGLWidget*)ctx, "update");
}

void PlayGLWidget::initMpvGL()
{
    if(m_mpvHandle)
    {
        m_mpvCallBack = (mpv_opengl_cb_context *)mpv_get_sub_api(m_mpvHandle, MPV_SUB_API_OPENGL_CB);
        if (!m_mpvCallBack)
        {
            KyInfo() << "get sub api error";
            return;
        }
        mpv_opengl_cb_set_update_callback(m_mpvCallBack, PlayGLWidget::on_update, (void *)this);
        connect(this, &PlayGLWidget::frameSwapped, this, &PlayGLWidget::swapped);
    }
}

void PlayGLWidget::initializeGL()
{
    if(m_mpvCallBack)
    {
        int r = mpv_opengl_cb_init_gl(m_mpvCallBack, NULL, get_proc_address, NULL);
        if (r < 0)
        {
            KyInfo("could not initialize OpenGL");
        }
    }
}

void PlayGLWidget::paintGL()
{
    if(m_mpvCallBack)
    {
        if(m_playState == Mpv::Playing || m_playState == Mpv::Paused)
        {
            QGSettings g("org.ukui.SettingsDaemon.plugins.xsettings");
            double scale = 1.0;
            // wayland 下高分辨适配不生效，所以 wayland 下默认 1 倍缩放就可以，如果 wayland 下窗口适配缩放后再去掉判断
            // 分屏问题？
//            if(!isWayland)
                scale = g.get("scaling-factor").toDouble();
            mpv_opengl_cb_draw(m_mpvCallBack, defaultFramebufferObject(), width()*scale, -height()*scale);
//            if (!isWayland) {
                parentWidget()->update();
//            }
        }
    }
}
