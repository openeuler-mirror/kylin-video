#ifndef MESSAGEBOX_H
#define MESSAGEBOX_H

#include "dialog.h"

class QLabel;
class QVBoxLayout;
class QHBoxLayout;

namespace KylinUI {

#define TITLE_ICON_WIDTH 20
#define TEXT_ICON_WIDTH 22
#define WIDGET_WIDTH 430
#define WIDGET_HEIGHT 152

enum MessageType{
    INFORMATION,
    QUESTION,
    WARNING,
    ABOUT
};

/// 没写静态函数，调用接直接临时变量exec，有个确认取消，写静态太麻烦

class MessageBox : public Dialog
{
    Q_OBJECT
public:
    MessageBox(QString title, QString text, QWidget *parent = nullptr, MessageType type = INFORMATION);
    ~MessageBox();

private:
    MessageType msg_type;
    QLabel  *lab_titleIcon,
            *lab_title,
            *lab_text,
            *lab_textIcon;
    QPushButton *btn_ok,
                *btn_cancel;
    QVBoxLayout *box_v;
    QHBoxLayout *box_ht,
                *box_hm,
                *box_hb;

    void setData(QString title, QString text);
    void initLayout();
};
}


#endif // MESSAGEBOX_H
