#ifndef PREVIEWWIDGET_H
#define PREVIEWWIDGET_H

#include "themewidget.h"
#include <mutex>
#include "global/global.h"

#include <libffmpegthumbnailer/videothumbnailer.h>
using namespace ffmpegthumbnailer;

class QFrame;
class QLabel;

class PreviewWidget : public ThemeWidget
{
    Q_OBJECT

public:
    explicit PreviewWidget(QWidget *parent = nullptr);
    ~PreviewWidget();

    void setHide();
    void setPreview(int time);
    void setMoveRange(int range){moveRange = range;}

    void setBlackTheme();
    void setDefaultTheme();

private:
    void initLayout();

    QWidget *m_widget;
    QFrame *m_frame;
    QLabel *m_previewLabel;
    QLabel *m_timeLabel;

    QString currentFile;
    int videoStream = -1;
    int duration;
    int previewTime = 0;
    int moveRange = 1;

signals:
    void updatePreview();

private slots:
    void slotFileInfoChange(Mpv::FileInfo info);
    void updatePos();

protected:
    std::mutex mux;
    VideoThumbnailer *m_videoTbr;
};

#endif // PREVIEWWIDGET_H
