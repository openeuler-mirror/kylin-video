#ifndef THEMEWIDGET_H
#define THEMEWIDGET_H

#include <QWidget>

#include "global/global.h"

using namespace Global;

class ThemeWidget : public QWidget
{
    Q_OBJECT
public:
    explicit ThemeWidget(QWidget *parent = nullptr):
        QWidget(parent)
    {
    }
    ~ThemeWidget(){}

    void connectThemeSetting(){
        if (FOLLOW_SYS_THEME) {
            if (g_settings->value("General/follow_system_theme").toBool()) {
                if(g_gsettings->get("styleName").toString() == STYLE_UKUI_DEFAULT)
                    setDefaultTheme();
                else
                    setBlackTheme();
            }
            else {
                if(g_settings->value("General/theme").toInt() == 0)
                    setDefaultTheme();
                else
                    setBlackTheme();
            }

            connect(g_gsettings, &QGSettings::changed, this, [&](QString key){
                // 如果不是跟随主题的话直接返回
                if (key == "styleName") {
                    if (g_settings->value("General/follow_system_theme").toBool()) {
                        if(g_gsettings->get("styleName").toString() == STYLE_UKUI_DEFAULT)
                            setDefaultTheme();
                        else
                            setBlackTheme();
                    }
                }
            });
        }
        else {
            setBlackTheme();
        }
    }

    virtual void setBlackTheme(){}
    virtual void setDefaultTheme(){}
};

#endif // THEMEWIDGET_H
