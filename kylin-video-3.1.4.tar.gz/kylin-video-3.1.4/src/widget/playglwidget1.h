#ifndef PLAYGLWIDGET_H
#define PLAYGLWIDGET_H

#include <QOpenGLWidget>
#include <QOpenGLFunctions>
#include <mpv/client.h>
#include <mpv/opengl_cb.h>
#include <mpv/qthelper.hpp>

#include "core/mpvtypes.h"

class PlayGLWidget : public QOpenGLWidget
{
public:
    PlayGLWidget(QWidget *parent = 0);
    ~PlayGLWidget();
    void setMpvHandle(mpv::qt::Handle _handle);

private slots:
    void swapped();

private:
    Mpv::PlayState m_playState;
    mpv::qt::Handle m_mpvHandle;
    mpv_opengl_cb_context *m_mpvCallBack;

    bool m_mouseUsed,
         m_isMouseEnter,
         m_hasVideo;

    int m_volumeChange;

    QPoint m_posStart;
    QPoint m_posLast;
    QPoint m_posCurrent;
    QPoint m_mousePosPressed;

    QTimer  *m_checkMouseTimer,
            *m_lMouseClickTimer;

    qint64 m_timePressStart;

    static void on_update(void *ctx);
    void initMpvGL();
    void initGlobalSig();

protected:
    void initializeGL() override;
    void paintGL() override;

//    void resizeEvent(QResizeEvent *e) override;
//    void mousePressEvent(QMouseEvent *e) override;
//    void mouseReleaseEvent(QMouseEvent *e) override;
//    void mouseMoveEvent(QMouseEvent *e) override;
//    void mouseDoubleClickEvent(QMouseEvent *e) override;
//    void enterEvent(QEvent *e) override;
//    void leaveEvent(QEvent *e) override;
//    bool event(QEvent *e) override;
};

#endif // PLAYGLWIDGET_H
