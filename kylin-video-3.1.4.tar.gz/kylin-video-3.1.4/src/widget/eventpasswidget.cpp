#include "eventpasswidget.h"

#include <QTimer>
#include <QDebug>
#include <QDateTime>
#include <QMouseEvent>
#include <QTouchEvent>

#include "global/globalsignal.h"
#include "global/global.h"

#include <ukui-log4qt.h>

using namespace Global;

EventPassWidget::EventPassWidget(QWidget *parent) :
    QWidget(parent)
{
//    setAttribute(Qt::WA_TranslucentBackground);
    setAttribute(Qt::WA_AcceptTouchEvents);
    setMouseTracking(true);

    m_mouseUsed = true;

    initGlobalSig();

    m_checkMouseTimer = new QTimer;
    m_checkMouseTimer->setInterval(2000);
    connect(m_checkMouseTimer, &QTimer::timeout, [&](){
        if(!m_hasVideo)
            return;
        if(m_isMouseEnter) {
            if (m_mouseUsed) {
                KyInfo() << "set cursor blank cursor";
                setCursor(QCursor(Qt::BlankCursor));
            }
        }
        g_user_signal->hideBar(true);

        m_checkMouseTimer->stop();
        return;
    });

    m_lMouseClickTimer = new QTimer;
    m_lMouseClickTimer->setInterval(300);
    connect(m_lMouseClickTimer, &QTimer::timeout, [&](){
        emit mousePressed();
        m_lMouseClickTimer->stop();
    });
}

EventPassWidget::~EventPassWidget()
{

}

void EventPassWidget::setMouseUsed(bool used)
{
    m_mouseUsed = used;
    if (!m_mouseUsed) {
        setCursor(QCursor(Qt::ArrowCursor));
        m_checkMouseTimer->stop();
    }
}

void EventPassWidget::playStateChange()
{
    if(g_playstate < 0) {
        m_checkMouseTimer->stop();
    }
    else {
        m_checkMouseTimer->start();
    }
}

void EventPassWidget::videIdChange(int vid)
{
    if(vid < 0)
        m_hasVideo = false;
    else
        m_hasVideo = true;
}

void EventPassWidget::initGlobalSig()
{
    connect(g_core_signal, &GlobalCoreSignal::sigStateChange, this, &EventPassWidget::playStateChange);
    connect(g_core_signal, &GlobalCoreSignal::sigVideoIdChange, this, &EventPassWidget::videIdChange);
}

void EventPassWidget::mousePressEvent(QMouseEvent *e)
{
    m_mousePosPressed = e->pos();
    m_posStart = e->pos();
    m_posLast = e->pos();

    // 右键点击触发显示菜单
    if (e->button() == Qt::LeftButton) {
        m_timePressStart = QDateTime::currentMSecsSinceEpoch();
    }
    return QWidget::mousePressEvent(e);
}

void EventPassWidget::mouseReleaseEvent(QMouseEvent *e)
{
    // 左键离开触发暂停，如果左键按得时间很长就不触发了，不然会和触摸屏长按冲突
    if (e->button() == Qt::LeftButton && (QDateTime::currentMSecsSinceEpoch() - m_timePressStart) < 500) {
        if (!m_mouseUsed)
            return QWidget::mouseReleaseEvent(e);
        if (e->pos() == m_mousePosPressed) {
            m_lMouseClickTimer->start();
        }
    }
    return QWidget::mouseReleaseEvent(e);
}

void EventPassWidget::mouseMoveEvent(QMouseEvent *e)
{
    m_isMouseEnter = true;
    m_checkMouseTimer->stop();
    setCursor(QCursor(Qt::ArrowCursor));
    g_user_signal->hideBar(false);
    if(g_playstate > 0)
        m_checkMouseTimer->start();
    e->accept();
}

void EventPassWidget::mouseDoubleClickEvent(QMouseEvent *e)
{
    if (!m_mouseUsed)
        return QWidget::mouseDoubleClickEvent(e);
    if(e->button() == Qt::LeftButton) {
        g_user_signal->fullScreen();
        m_lMouseClickTimer->stop();
    }
    return QWidget::mouseDoubleClickEvent(e);
}

void EventPassWidget::enterEvent(QEvent *e)
{
    m_isMouseEnter = true;
    e->accept();
}

void EventPassWidget::leaveEvent(QEvent *e)
{
    m_isMouseEnter = false;
    if(g_playstate > 0)
        m_checkMouseTimer->start();

    return QWidget::leaveEvent(e);
}

bool EventPassWidget::event(QEvent *e)
{
//    if (e->type() == QEvent::ContextMenu) {
//        setCursor(Qt::ArrowCursor);
//        m_isMouseEnter = false;
//        g_user_signal->showRightMenu();
//        return QWidget::event(e);
//    }

    return QWidget::event(e);
}

bool EventPassWidget::eventFilter(QObject *watched, QEvent *e)
{
    if (e->type() == QEvent::MouseMove) {
        m_isMouseEnter = true;
        m_checkMouseTimer->stop();
        setCursor(QCursor(Qt::ArrowCursor));
        g_user_signal->hideBar(false);
        if(g_playstate > 0)
            m_checkMouseTimer->start();
        e->accept();
    }
    return QWidget::eventFilter(watched, e);
}
