#include "dialog.h"
#include <QMouseEvent>
#include <QEvent>
#include <QDebug>

#include "widget/ukui-wayland/ukui-decoration-manager.h"
#include "widget/xatom-helper.h"
#include "global/global.h"

Dialog::Dialog(QWidget *parent):
    QDialog(parent)
{
    if(Global::isWayland)
        installEventFilter(this);
    else {
        MotifWmHints hints1;
        hints1.flags = MWM_HINTS_FUNCTIONS | MWM_HINTS_DECORATIONS;
        hints1.functions = MWM_FUNC_ALL;
        hints1.decorations = MWM_DECOR_BORDER;
        XAtomHelper::getInstance()->setWindowMotifHint(winId(), hints1);
    }
}

Dialog::~Dialog()
{

}

void Dialog::ukuiMove()
{
    if(Global::isWayland)
        UKUIDecorationManager::getInstance()->moveWindow(this->windowHandle());
}

bool Dialog::eventFilter(QObject *watched, QEvent *event)
{
    if(watched == this)
    {
        if (event->type() == QEvent::MouseButtonPress){
            auto mouseEvent = static_cast<QMouseEvent *>(event);
            if (mouseEvent->buttons() & Qt::LeftButton) {
                ukuiMove();
            }
        }
    }
    return false;
}

void Dialog::showEvent(QShowEvent *event)
{
    QDialog::showEvent(event);
    if(Global::isWayland)
        UKUIDecorationManager::getInstance()->removeHeaderBar(windowHandle());
}
