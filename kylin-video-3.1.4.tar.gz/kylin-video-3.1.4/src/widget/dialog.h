#ifndef DIALOG_H
#define DIALOG_H

#include <QDialog>

/// wayland 下无边框 dialog

class Dialog : public QDialog
{
    Q_OBJECT
public:
    Dialog(QWidget *parent = nullptr);
    ~Dialog();

private:
    void ukuiMove();

protected:
    bool eventFilter(QObject *watched, QEvent *event) override;
    void showEvent(QShowEvent *event) override;
};

#endif // DIALOG_H
