#include "messagebox.h"

#include <QLabel>
#include <QPushButton>
#include <QVBoxLayout>
#include <QHBoxLayout>

namespace KylinUI {
MessageBox::MessageBox(QString title, QString text, QWidget *parent, MessageType type) :
    Dialog(parent)
{
    msg_type = type;
    initLayout();
    setData(title, text);
}

MessageBox::~MessageBox()
{
    delete lab_titleIcon;
    delete lab_title;
    delete lab_text;
    delete lab_textIcon;
    delete btn_ok;
    delete box_hb;
    delete box_hm;
    delete box_ht;
    delete box_v;
}

void MessageBox::setData(QString title, QString text)
{
    QIcon icMsg, icTitle = QIcon::fromTheme("kylin-video");
    switch (msg_type) {
    case INFORMATION:
        icMsg = QIcon::fromTheme("ukui-dialog-information");
        btn_cancel->hide();
        break;
    case QUESTION:
        icMsg = QIcon::fromTheme("ukui-dialog-help");
        break;
    case WARNING:
        icMsg = QIcon::fromTheme("ukui-dialog-warning");
        btn_cancel->hide();
        break;
    case ABOUT:
        icMsg = QIcon::fromTheme("about");
        btn_cancel->hide();
        break;
    default:
        break;
    }

    lab_title->setText(title);
    lab_titleIcon->setPixmap(icTitle.pixmap(lab_titleIcon->size()));
    lab_text->setText(text);
    lab_textIcon->setPixmap(icMsg.pixmap(lab_textIcon->size()));
}

void MessageBox::initLayout()
{
    setFixedSize(WIDGET_WIDTH, WIDGET_HEIGHT);

    box_ht = new QHBoxLayout;
    box_hm = new QHBoxLayout;
    box_hb = new QHBoxLayout;
    box_v = new QVBoxLayout(this);

    box_v->addLayout(box_ht);
    box_v->addSpacing(15);
    box_v->addLayout(box_hm);
    box_v->addStretch();
    box_v->addLayout(box_hb);

    lab_titleIcon = new QLabel;
    lab_titleIcon->setFixedSize(TITLE_ICON_WIDTH, TITLE_ICON_WIDTH);
    lab_title = new QLabel;

    box_ht->addWidget(lab_titleIcon);
    box_ht->addWidget(lab_title);
    box_ht->addStretch();

    lab_text = new QLabel;
    lab_textIcon = new QLabel;
    lab_textIcon->setFixedSize(TEXT_ICON_WIDTH, TEXT_ICON_WIDTH);
    box_hm->addSpacing(24);
    box_hm->addWidget(lab_textIcon);
    box_hm->addWidget(lab_text);
    box_hm->addStretch();

    btn_cancel = new QPushButton;
    btn_cancel->setFixedSize(93, 30);
    btn_cancel->setText(tr("Cancel"));

    btn_ok = new QPushButton;
    btn_ok->setFixedSize(93, 30);
    btn_ok->setText(tr("Ok"));

    connect(btn_cancel, &QPushButton::clicked, this, &MessageBox::reject);
    connect(btn_ok, &QPushButton::clicked, this, &MessageBox::accept);
    box_hb->addStretch();
    box_hb->addWidget(btn_cancel);
    box_hb->addWidget(btn_ok);
    box_hb->setContentsMargins(0, 0, 16, 8);
}
}
