#ifndef SETUPDIALOG_H
#define SETUPDIALOG_H

#include <QDialog>
//#include <knavigationbar.h>

//using namespace kdk;

class SetupSystem;
class SetupPlay;
class SetupScreenshot;
class SetupSubtitle;
class SetupVolume;
class SetupCodec;
class SetupShortcut;

namespace Ui {
class SetUpDialog;
}

class SetUpDialog : public QDialog
{
    Q_OBJECT

public:
    explicit SetUpDialog(QWidget *parent = nullptr);
    ~SetUpDialog();
    void setIndex(int index);

private:
    Ui::SetUpDialog *ui;

    SetupSystem     *m_systemPage;
    SetupPlay       *m_playPage;
    SetupScreenshot *m_screenshotPage;
    SetupSubtitle   *m_subtitlePage;
    SetupVolume     *m_volumePage;
    SetupCodec      *m_codecPage;
    SetupShortcut   *m_shortcutPage;

//    KNavigationBar *leftBar;

    void initStyle();
    void initListWidget();
    void initConnect();
    void resetFont();

private slots:
    void slotChangeTheme(bool is_black_theme);
    void showEvent(QShowEvent *e);
    void hideEvent(QHideEvent *e);
    bool eventFilter(QObject *watched, QEvent *event);
};

#endif // SETUPDIALOG_H
