#ifndef WAYLANDDIALOG_H
#define WAYLANDDIALOG_H

#include <QDialog>
#include "ukui-decoration-client.h"
#include "ukui-decoration-manager.h"

namespace Ui {
class WaylandDialog;
}

class WaylandDialog : public QDialog
{
    Q_OBJECT

public:
    explicit WaylandDialog(QWidget *parent = nullptr);
    ~WaylandDialog();

    void setText(QString text);

private:
    Ui::WaylandDialog *ui;
};

#endif // WAYLANDDIALOG_H
