#include <stdlib.h>
#include <stdint.h>
#include "wayland-util.h"

#ifndef __has_attribute
# define __has_attribute(x) 0  /* Compatibility with non-clang compilers. */
#endif

#if (__has_attribute(visibility) || defined(__GNUC__) && __GNUC__ >= 4)
#define WL_PRIVATE __attribute__ ((visibility("hidden")))
#else
#define WL_PRIVATE
#endif

extern const struct wl_interface wl_surface_interface;
static const struct wl_interface *custom_types[] = {
	&wl_surface_interface,
	NULL,
};
	static const struct wl_message ukui_raise_requests[] = {
		{ "set_top", "o", custom_types + 0 }
	};

	WL_PRIVATE const struct wl_interface ukui_raise_interface = {
		"ukui_raise", 1,
		1, ukui_raise_requests,
		0, NULL,
	};


