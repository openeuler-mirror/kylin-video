#ifndef UKUIDECORATIONMANAGER_H
#define UKUIDECORATIONMANAGER_H

#include <QWindow>

class UKUIDecorationManager
{
public:
    static UKUIDecorationManager *getInstance();
    bool supportUKUIDecoration();

    bool moveWindow(QWindow *windowHandle);
    bool removeHeaderBar(QWindow *windowHandle);
    bool setCornerRadius(QWindow *windowHandle, int topleft, int topright, int bottomleft, int bottomright);

private:
    UKUIDecorationManager();
};

#endif // UKUIDECORATIONMANAGER_H
