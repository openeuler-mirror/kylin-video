#include "previewwidget.h"

#include <QVBoxLayout>
#include <QGSettings>
#include <QPainter>
#include <QThread>
#include <QDebug>
#include <QFrame>
#include <QLabel>
#include <QTime>

#include <ukui-log4qt.h>

//#include "core/util.h"
#include "global/path.h"
#include "global/functions.h"

#include <syslog.h>

using namespace Global;

PreviewWidget::PreviewWidget(QWidget *parent) :
    ThemeWidget(parent)
{
    initLayout();

    setAttribute(Qt::WA_TranslucentBackground);
    m_videoTbr = new VideoThumbnailer;
    m_videoTbr->setThumbnailSize(176);
    currentFile = "";
    connect(g_core_signal, &GlobalCoreSignal::sigDuration, [&](QString file, double duration){
        if (currentFile == file)
            this->duration = duration;
    });

    connect(g_core_signal, &GlobalCoreSignal::sigFileInfoChange, this, &PreviewWidget::slotFileInfoChange);
    connect(this, &PreviewWidget::updatePreview, this, [this](){
        updatePos();
        QString time_str = Functions::timeToStr((double)previewTime);
        m_timeLabel->setText(time_str);
        m_previewLabel->setStyleSheet(QString("border-radius:8px;border-image:url(%1);")
                                         .arg(QDir::homePath().append("/.config/kylin-video/tmp-preview.png")));
        show();
    });

    QFont f("Noto Sans CJK SC Regular");
    f.setPixelSize(16);
    m_timeLabel->setFont(f);
    m_timeLabel->setAlignment(Qt::AlignCenter);
    m_previewLabel->setFixedSize(192, 108);
    m_frame->setFixedSize(192, 108);

    connectThemeSetting();
}

PreviewWidget::~PreviewWidget()
{
}

void PreviewWidget::setHide()
{
    previewTime = -1;
    hide();
}

void PreviewWidget::setBlackTheme()
{
    m_widget->setStyleSheet("QWidget#widget{background-color:rgba(28,28,28,0);}");
    m_timeLabel->setStyleSheet("background-color:rgba(0,0,0,0);color:rgb(222,222,222)");
    m_frame->setStyleSheet("background-color:rgba(1,1,1,110);border-radius:8px;");
}

void PreviewWidget::setDefaultTheme()
{
    m_widget->setStyleSheet("QWidget#widget{background-color:rgba(223,223,223,0);}QLabel{background-color:rgb(223,223,223);}");
    m_timeLabel->setStyleSheet("background-color:rgba(0,0,0,0);color:rgb(222,222,222)");
    m_frame->setStyleSheet("background-color:rgba(1,1,1,110);border-radius:8px;");
}

void PreviewWidget::initLayout()
{
    QVBoxLayout *lay = new QVBoxLayout(this);
    lay->setContentsMargins(0, 0, 0, 0);

    m_widget = new QWidget(this);
    lay->addWidget(m_widget);

    m_frame = new QFrame(m_widget);
    QVBoxLayout *lay_frame = new QVBoxLayout(m_frame);
    lay_frame->setContentsMargins(0, 0, 0, 0);
    lay_frame->setSpacing(0);

    m_previewLabel = new QLabel;
    lay_frame->addWidget(m_previewLabel);

    m_timeLabel = new QLabel;
    lay_frame->addWidget(m_timeLabel);
}

void PreviewWidget::setPreview(int time)
{
    previewTime = time;
    QString time_str = Functions::timeToStr((double)previewTime);
    QThread::create([this, time_str, time](){
        // 应该放到线程中去做
        QString tmp_path = QDir::homePath().append("/.config/kylin-video/tmp-preview.png");
        // 如果文件不存在返回
        QFileInfo fi(currentFile);
        if (!fi.exists()) {
            QImage img(":/ico/no-preview.png");
            img.save(tmp_path);
        }
        else {
            m_videoTbr->setSeekTime(time_str.toStdString());
            m_videoTbr->generateThumbnail(currentFile.toStdString(), Png, tmp_path.toStdString());
        }

        if (previewTime == time)
            emit updatePreview();
    })->start();
}

void PreviewWidget::slotFileInfoChange(Mpv::FileInfo info)
{
    currentFile = info.file_path;
    duration = info.length;
    previewTime = 0;
}

void PreviewWidget::updatePos()
{
    // 更新位置，跟着鼠标走
    if(previewTime == 0)
        previewTime = 1;
    int x = (double)previewTime * (double)moveRange / (double)duration - (m_previewLabel->width() / 2) + 240;
    int y = height() - 75 - m_previewLabel->height();
    m_frame->move(x, y);
}
