#ifndef TESTWIDGET_H
#define TESTWIDGET_H

#include <QWidget>
#include <mpv/client.h>
#include <mpv/opengl_cb.h>
#include <mpv/qthelper.hpp>

#include "widget/playglwidget.h"
#include "core/mpvcore.h"

class TestWidget : public QWidget
{
    Q_OBJECT
public:
    explicit TestWidget(QWidget *parent = nullptr);

signals:

private:
    mpv::qt::Handle mpv;

    PlayGLWidget *gl_w;
    MpvCore *m_core;
};

#endif // TESTWIDGET_H
