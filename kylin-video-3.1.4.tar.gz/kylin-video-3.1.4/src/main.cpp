#include "mainwindow.h"

#include <QDesktopWidget>
#include <QApplication>
#include <QScreen>
#include <QIcon>

#include "testwidget.h"
#include "mainwindow.h"
#include "global/global.h"
#include "global/globalconfig.h"

#include <ukui-log4qt.h>

int main(int argc, char *argv[])
{
    initUkuiLog4qt("kylin-video");

    if(Global::isWayland)
    {
#if 0
        qputenv("QT_QPA_PLATFORM", "wayland");
#endif
    }
    else {
#if (QT_VERSION >= QT_VERSION_CHECK(5, 6, 0))
        QApplication::setAttribute(Qt::AA_EnableHighDpiScaling);
        QApplication::setAttribute(Qt::AA_UseHighDpiPixmaps);
#endif
    }

//    if (Global::g_config->hardwareType() == GlobalConfig::INTEL_IrisXe_VAAPI)
        qputenv("QT_XCB_GL_INTEGRATION", "xcb_egl");

    QApplication a(argc, argv);
    a.setWindowIcon(QIcon::fromTheme("kylin-video"));

    Global::global_init();

    QStringList arg_list;
    for(int i=1; i<argc; i++)
    {
        QFileInfo f(QString(argv[i]));
        if(f.isFile())
            arg_list << f.absoluteFilePath();
    }

    MainWindow w(arg_list);
//    QWidget w;

    if (Global::isWayland) {
        kdk::UkuiStyleHelper::self()->removeHeader(&w);
        w.show();
        kdk::WindowManager::setGeometry(w.windowHandle(),
                                        QRect(qApp->desktop()->geometry().center() - w.geometry().center(),
                                        QSize(w.size())));
    }
    else {
        w.show();
        w.move(qApp->primaryScreen()->availableGeometry().center() - w.geometry().center());
    }

    return a.exec();
}
