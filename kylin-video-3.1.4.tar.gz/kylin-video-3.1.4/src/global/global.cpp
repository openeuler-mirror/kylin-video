#include "global.h"

#include <QSettings>
#include <QGSettings>
#include <QApplication>
#include <QFile>
#include <QDebug>
#include "translator.h"
#include "path.h"

QSettings       *Global::g_settings     = nullptr;
Translator      *Global::translator     = nullptr;
SqliteHandle    *Global::g_sqlite       = nullptr;
GlobalConfig    *Global::g_config       = nullptr;
QGSettings      *Global::g_gsettings    = nullptr;
ShortCutSetting *Global::g_shortCut     = nullptr;
QGSettings      *Global::g_gsettings_control_center = nullptr;
Mpv::PlayState  Global::g_playstate     = Mpv::Idle;
bool Global::isWayland = false;
//KPlayControl *Global::k_playcontrol = KPlayControl::getInstanece();

using namespace Global;

void Global::global_init() {

    // Translator
    translator = new Translator();

    // g_settings
    QString filename = Paths::iniPath() + "/kylin-video3.ini";
    QString dbname = Paths::iniPath() + "/kylin-video3.db";

    g_settings = new QSettings(filename, QSettings::IniFormat);
    g_settings->setIniCodec("UTF-8");
    // 运行环境
    if(!g_settings->contains("General/display_env"))
    {
        if((QString(qgetenv("XDG_SESSION_TYPE")) == "wayland"))
            g_settings->setValue("General/display_env", "wayland");
        else
            g_settings->setValue("General/display_env", "x11");
    }
    isWayland   = QString(qgetenv("XDG_SESSION_TYPE")) == "wayland";

    g_gsettings = new QGSettings(ORG_UKUI_STYLE);
    g_gsettings_control_center = new QGSettings(PERSONALISE_SHEME);

    g_shortCut  = ShortCutSetting::getInstance(g_settings);
    g_sqlite    = SqliteHandle::getInstance(dbname);
    g_config    = GlobalConfig::getInstance();
}

void Global::global_end() {
    delete g_gsettings;
    delete g_gsettings_control_center;
    delete g_settings;
    delete translator;
}
