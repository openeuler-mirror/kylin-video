<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="bo_CN">
<context>
    <name>AboutDialog</name>
    <message>
        <location filename="../widget/aboutdialog.ui" line="26"/>
        <source>Dialog</source>
        <translation>Dialog</translation>
    </message>
    <message>
        <location filename="../widget/aboutdialog.ui" line="189"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;Video Player&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt; &lt;head/&gt; &lt;body&gt; &lt;p align=&quot;center&quot;&gt; བརྙན་ཕབ་འཕྲུལ་འཁོར&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../widget/aboutdialog.ui" line="199"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;version: 3.1.1&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt; &lt;head/&gt; &lt;body&gt; &lt;p align=&quot;center&quot;&gt;པར་གཞི། 3.1.1&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../widget/aboutdialog.ui" line="230"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Noto Sans Mono CJK SC&apos;; font-size:12pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Noto Sans CJK SC&apos;; font-size:11pt;&quot;&gt;Video Player is a front player with beautiful interface and good interaction. It is developed with Qt5 and uses MPV as the playback engine. Video Player supports almost all audio and video formats and has powerful decoding ability.&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt; &lt;head&gt; &lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt; &lt;style type=&quot;text/css&quot;&gt;
p, li {དཀར་པོའི་བར་སྟོང་། སྔོན་ཚུད་ནས་ཐུམ་སྒྲིལ།}
&lt;/style&gt; &lt;/head&gt; &lt;body style=&quot; font-family:&apos;Noto Sans Mono CJK SC&apos;; font-size:12pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt; &lt;span style=&quot; font-family:&apos;Noto Sans CJK SC&apos;; font-size:11pt;&quot;&gt; བརྙན་ཕབ་འཕྲུལ་ཆས་ནི་མཛེས་སྡུག་ལྡན་པའི་འབྲེལ་མཐུད་དང་ཕན་ཚུན་ནུས་པ་འདོན་སྤེལ་བྱེད་པའི་མདུན་ དེ་ནི་Qt5དང་མཉམ་དུ་གསར་སྤེལ་བྱས་པ་མ་ཟད་MPVདེ་ཕྱིར་ལྡོག་བྱེད་པའི་སྒུལ་བྱེད་འཕྲུལ་འཁོར་དུ་བཀོལ་བ་རེད། བརྙན་ཕབ་འཕྲུལ་ཆས་ཀྱིས་ཧ་ལམ་སྒྲ་དང་བརྙན་ཕབ་ཀྱི་རྣམ་པ་ཡོད་ཚད་ལ་རྒྱབ་སྐྱོར་བྱས་ནས་ནུས་ལྡན་གྱི་ཨང་སྒྲིག་ནུས་པ་ལྡན་པ་རེད། &lt;/span&gt; &lt;/p&gt; &lt;/body&gt; &lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../widget/aboutdialog.ui" line="254"/>
        <source>service and support: support@kylinos.cn</source>
        <translation>ཞབས་ཞུ་དང་རྒྱབ་སྐྱོར། support@kylinos.cn</translation>
    </message>
    <message>
        <location filename="../widget/aboutdialog.cpp" line="39"/>
        <source>version: </source>
        <translation>版本： </translation>
    </message>
    <message>
        <location filename="../widget/aboutdialog.cpp" line="40"/>
        <source>service and support: </source>
        <translation>ཞབས་ཞུ་དང་རྒྱབ་སྐྱོར་བྱ་རྒྱུ་སྟེ། </translation>
    </message>
    <message>
        <location filename="../widget/aboutdialog.cpp" line="63"/>
        <location filename="../widget/aboutdialog.cpp" line="77"/>
        <source>Service &amp; Support: </source>
        <translation>ཞབས་ཞུ་ &amp; Support: </translation>
    </message>
    <message>
        <location filename="../widget/aboutdialog.cpp" line="103"/>
        <source>Video Player About</source>
        <translation>བརྙན་ཕབ་འཕྲུལ་འཁོར་གྱི་སྐོར།</translation>
    </message>
    <message>
        <location filename="../widget/aboutdialog.cpp" line="120"/>
        <source>Video Player</source>
        <translation>བརྙན་ཕབ་འཕྲུལ་འཁོར།</translation>
    </message>
</context>
<context>
    <name>ContralBar</name>
    <message>
        <source>Form</source>
        <translation type="vanished">Form</translation>
    </message>
    <message>
        <source>--:--:--/--:--:--</source>
        <translation type="vanished">--:--:--/--:--:--</translation>
    </message>
    <message>
        <location filename="../widget/contralbar.cpp" line="462"/>
        <source>Next</source>
        <translation>གཞས་རྗེས་མ་</translation>
    </message>
    <message>
        <location filename="../widget/contralbar.cpp" line="463"/>
        <source>Previous</source>
        <translation>གཞས་སྔོན་མ་</translation>
    </message>
    <message>
        <location filename="../widget/contralbar.cpp" line="464"/>
        <location filename="../widget/contralbar.cpp" line="718"/>
        <source>Play</source>
        <translation>གཏོང་བ་</translation>
    </message>
    <message>
        <location filename="../widget/contralbar.cpp" line="465"/>
        <source>Volume</source>
        <translation>རང་སའི་ཁུལ་བགོས།</translation>
    </message>
    <message>
        <location filename="../widget/contralbar.cpp" line="466"/>
        <source>Speed</source>
        <translation>མྱུར་ཚད།</translation>
    </message>
    <message>
        <location filename="../widget/contralbar.cpp" line="467"/>
        <source>Tools</source>
        <translation>ཡོ་བྱད།</translation>
    </message>
    <message>
        <location filename="../widget/contralbar.cpp" line="468"/>
        <location filename="../widget/contralbar.cpp" line="754"/>
        <source>Full screen</source>
        <translation>བརྙན་ཤེལ་ཧྲིལ་པོ།</translation>
    </message>
    <message>
        <location filename="../widget/contralbar.cpp" line="540"/>
        <location filename="../widget/contralbar.cpp" line="696"/>
        <source>Screen shot</source>
        <translation>བརྙན་ཤེལ་གྱི་པར་ལེན</translation>
    </message>
    <message>
        <location filename="../widget/contralbar.cpp" line="658"/>
        <source>2.0X</source>
        <translation>2.0X</translation>
    </message>
    <message>
        <location filename="../widget/contralbar.cpp" line="659"/>
        <source>1.5X</source>
        <translation>1.5X</translation>
    </message>
    <message>
        <location filename="../widget/contralbar.cpp" line="660"/>
        <source>1.25X</source>
        <translation>1.25X</translation>
    </message>
    <message>
        <location filename="../widget/contralbar.cpp" line="661"/>
        <source>1.0X</source>
        <translation>1.0X</translation>
    </message>
    <message>
        <location filename="../widget/contralbar.cpp" line="662"/>
        <source>0.75X</source>
        <translation>0.75X</translation>
    </message>
    <message>
        <location filename="../widget/contralbar.cpp" line="663"/>
        <source>0.5X</source>
        <translation>0.5X</translation>
    </message>
    <message>
        <location filename="../widget/contralbar.cpp" line="696"/>
        <source>Add mark</source>
        <translation>རྟགས་ཁ་སྣོན་བྱེད་པ།</translation>
    </message>
    <message>
        <location filename="../widget/contralbar.cpp" line="714"/>
        <source>Pause</source>
        <translation>གནས་སྐབས་མཚམས་འཇོག་</translation>
    </message>
    <message>
        <location filename="../widget/contralbar.cpp" line="751"/>
        <source>Exit full screen</source>
        <translation>བརྙན་ཤེལ་ཧྲིལ་བོ་ཕྱིར་འབུད་</translation>
    </message>
</context>
<context>
    <name>GlobalConfig</name>
    <message>
        <location filename="../global/globalconfig.cpp" line="428"/>
        <location filename="../global/globalconfig.cpp" line="440"/>
        <location filename="../global/globalconfig.cpp" line="445"/>
        <location filename="../global/globalconfig.cpp" line="462"/>
        <location filename="../global/globalconfig.cpp" line="470"/>
        <source>auto</source>
        <translation>རང་འགུལ་གྱིས་རླངས་</translation>
    </message>
    <message>
        <location filename="../global/globalconfig.cpp" line="467"/>
        <location filename="../global/globalconfig.cpp" line="471"/>
        <source>default</source>
        <translation>ཁ་ཆད་དང་འགལ་</translation>
    </message>
</context>
<context>
    <name>GlobalSetup</name>
    <message>
        <source>auto</source>
        <translation type="vanished">རང་འགུལ་གྱིས་རླངས་</translation>
    </message>
    <message>
        <source>default</source>
        <translation type="vanished">ཁ་ཆད་དང་འགལ་</translation>
    </message>
</context>
<context>
    <name>HomePage</name>
    <message>
        <location filename="../widget/homepage.cpp" line="25"/>
        <source>open file</source>
        <translation>ཁ་ཕྱེ་བའི་ཡིག་ཆ།</translation>
    </message>
    <message>
        <location filename="../widget/homepage.cpp" line="35"/>
        <source>open directory</source>
        <translation>ཁ་ཕྱེས་པའི་ཉིན་ཐོ།</translation>
    </message>
    <message>
        <source>open dir</source>
        <translation type="vanished">ཁ་ཕྱེས་པའི་ཉིན་ཐོ།</translation>
    </message>
    <message>
        <location filename="../widget/homepage.cpp" line="52"/>
        <source>Video Player</source>
        <translation>བརྙན་ཕབ་འཕྲུལ་འཁོར།</translation>
    </message>
</context>
<context>
    <name>KRightClickMenu</name>
    <message>
        <location filename="../widget/kmenu.cpp" line="184"/>
        <source>Open &amp;File...</source>
        <translation>ཁ་ཕྱེ་ནས་ཡིག་ཆ་</translation>
    </message>
    <message>
        <location filename="../widget/kmenu.cpp" line="185"/>
        <source>open file</source>
        <translation>ཁ་ཕྱེ་བའི་ཡིག་ཆ།</translation>
    </message>
    <message>
        <location filename="../widget/kmenu.cpp" line="189"/>
        <source>Open &amp;Directory...</source>
        <translation>སྒོ་འབྱེད་དང་དཀར་ཆག་ ...</translation>
    </message>
    <message>
        <location filename="../widget/kmenu.cpp" line="190"/>
        <source>open dir</source>
        <translation>ཁ་ཕྱེས་པའི་ཉིན་ཐོ།</translation>
    </message>
    <message>
        <location filename="../widget/kmenu.cpp" line="208"/>
        <source>to top</source>
        <translation>གོང་ནས་འོག་བར་དུ།</translation>
    </message>
    <message>
        <location filename="../widget/kmenu.cpp" line="218"/>
        <source>ToTop</source>
        <translation>ཐོ་ལོ་ཐོ་ཧྥུ།</translation>
    </message>
    <message>
        <location filename="../widget/kmenu.cpp" line="227"/>
        <source>Order</source>
        <translation>མངགས་ཐོ།</translation>
    </message>
    <message>
        <location filename="../widget/kmenu.cpp" line="230"/>
        <source>One Loop</source>
        <translation>འཁོར་སྐྱོད་ཐེངས་གཅིག</translation>
    </message>
    <message>
        <location filename="../widget/kmenu.cpp" line="234"/>
        <source>Sequence</source>
        <translation>གོ་རིམ།</translation>
    </message>
    <message>
        <location filename="../widget/kmenu.cpp" line="238"/>
        <source>List loop</source>
        <translation>རེའུ་མིག་འཁོར་སྐྱོད་བྱེད་བཞིན</translation>
    </message>
    <message>
        <location filename="../widget/kmenu.cpp" line="242"/>
        <source>Random</source>
        <translation>སྐབས་བསྟུན་ཁྱབ་གཏོང་</translation>
    </message>
    <message>
        <location filename="../widget/kmenu.cpp" line="291"/>
        <source>Frame</source>
        <translation>སྒྲོམ་གཞི།</translation>
    </message>
    <message>
        <location filename="../widget/kmenu.cpp" line="297"/>
        <source>Default frame</source>
        <translation>ཁ་ཆད་དང་འགལ་བའི་</translation>
    </message>
    <message>
        <location filename="../widget/kmenu.cpp" line="301"/>
        <source>4:3</source>
        <translation>4:3</translation>
    </message>
    <message>
        <location filename="../widget/kmenu.cpp" line="305"/>
        <source>16:9</source>
        <translation>16:9</translation>
    </message>
    <message>
        <location filename="../widget/kmenu.cpp" line="309"/>
        <source>Full frame</source>
        <translation>སྒྲོམ་གཞི་ཆ་ཚང་།</translation>
    </message>
    <message>
        <location filename="../widget/kmenu.cpp" line="333"/>
        <location filename="../widget/kmenu.cpp" line="339"/>
        <source>restore frame</source>
        <translation>སླར་གསོ་བྱེད་པའི་སྒྲོམ་གཞི</translation>
    </message>
    <message>
        <location filename="../widget/kmenu.cpp" line="341"/>
        <location filename="../widget/kmenu.cpp" line="347"/>
        <source>forward rotate</source>
        <translation>མདུན་སྐྱོད་ཀྱི་འཁོར་སྐྱོད།</translation>
    </message>
    <message>
        <location filename="../widget/kmenu.cpp" line="346"/>
        <source>Along rotate</source>
        <translation>འཁོར་སྐྱོད་བྱེད་བཞིན་ཡོད།</translation>
    </message>
    <message>
        <location filename="../widget/kmenu.cpp" line="349"/>
        <location filename="../widget/kmenu.cpp" line="355"/>
        <source>backward rotate</source>
        <translation>རྗེས་ལུས་ཀྱི་འཁོར་སྐྱོད།</translation>
    </message>
    <message>
        <location filename="../widget/kmenu.cpp" line="354"/>
        <source>Inverse rotate</source>
        <translation>ལྡོག་ཕྱོགས་སུ་འཁོར་སྐྱོད་བྱེད་པ།</translation>
    </message>
    <message>
        <location filename="../widget/kmenu.cpp" line="357"/>
        <location filename="../widget/kmenu.cpp" line="360"/>
        <source>horizontal flip</source>
        <translation>འཕྲེད་ཕྱོགས་ཀྱི་འདྲུད་འཐེན་འཕྲུལ་</translation>
    </message>
    <message>
        <location filename="../widget/kmenu.cpp" line="359"/>
        <source>Horizontally flip</source>
        <translation>འཕྲེད་ཕྱོགས་ནས་ཕར་འགྲོ་ཚུར་འོང་བྱེད</translation>
    </message>
    <message>
        <location filename="../widget/kmenu.cpp" line="362"/>
        <location filename="../widget/kmenu.cpp" line="365"/>
        <source>vertical flip</source>
        <translation>གཞུང་ཕྱོགས་ནས་ཕར་འགྲོ་ཚུར་འོང་བྱེད</translation>
    </message>
    <message>
        <location filename="../widget/kmenu.cpp" line="364"/>
        <source>Vertically flip</source>
        <translation>གཞུང་ཕྱོགས་ནས་ཕར་འགྲོ་ཚུར་འོང་བྱེད་པ།</translation>
    </message>
    <message>
        <location filename="../widget/kmenu.cpp" line="371"/>
        <source>Show profile</source>
        <translation>ངོ་སྤྲོད་མདོར་བསྡུས།</translation>
    </message>
    <message>
        <location filename="../widget/kmenu.cpp" line="393"/>
        <source>Audio</source>
        <translation>སྒྲ་ཕབ།</translation>
    </message>
    <message>
        <location filename="../widget/kmenu.cpp" line="396"/>
        <source>AudioTrack</source>
        <translation>སྒྲ་ཕབ་འཕྲུལ་ཆས།</translation>
    </message>
    <message>
        <location filename="../widget/kmenu.cpp" line="406"/>
        <source>AudioChannel</source>
        <translation>སྒྲ་ཕབ་འཕྲུལ་ཆས།</translation>
    </message>
    <message>
        <location filename="../widget/kmenu.cpp" line="413"/>
        <source>Default</source>
        <translation>ཁ་ཆད་དང་འགལ་</translation>
    </message>
    <message>
        <location filename="../widget/kmenu.cpp" line="420"/>
        <source>Stereo</source>
        <translation>སྒྲ་སྐྱེད་འཕྲུལ་འཁོར།</translation>
    </message>
    <message>
        <location filename="../widget/kmenu.cpp" line="427"/>
        <source>Left channel</source>
        <translation>གཡོན་ཕྱོགས་ཀྱི་བགྲོད་ལམ།</translation>
    </message>
    <message>
        <location filename="../widget/kmenu.cpp" line="434"/>
        <source>Right channel</source>
        <translation>ཡང་དག་པའི་ཐབས་ལམ།</translation>
    </message>
    <message>
        <location filename="../widget/kmenu.cpp" line="469"/>
        <source>Audio set</source>
        <translation>སྒྲ་ཕབ་འཕྲུལ་ཆས།</translation>
    </message>
    <message>
        <location filename="../widget/kmenu.cpp" line="483"/>
        <source>Subtitle</source>
        <translation>ཡིག་བརྙན་གྱི་ཡིག་བརྙན།</translation>
    </message>
    <message>
        <location filename="../widget/kmenu.cpp" line="486"/>
        <source>sub load</source>
        <translation>ཡན་ལག་གི་ཐེག་ཚད།</translation>
    </message>
    <message>
        <location filename="../widget/kmenu.cpp" line="534"/>
        <location filename="../widget/kmenu.cpp" line="552"/>
        <source>Video Player Choose a file</source>
        <translation>བརྙན་ཕབ་འཕྲུལ་འཁོར་གྱིས་ཡིག་ཆ་ཞིག་བདམས་</translation>
    </message>
    <message>
        <location filename="../widget/kmenu.cpp" line="536"/>
        <location filename="../widget/kmenu.cpp" line="554"/>
        <source>Subtitles</source>
        <translation>ཡིག་བརྙན་གྱི་ཡིག་བརྙན།</translation>
    </message>
    <message>
        <location filename="../widget/kmenu.cpp" line="555"/>
        <source>All files</source>
        <translation>ཡིག་ཆ་ཡོད་ཚད།</translation>
    </message>
    <message>
        <location filename="../widget/kmenu.cpp" line="561"/>
        <source>Load subtitle</source>
        <translation>ཡིག་བརྙན་གྱི་ཡིག་བརྙན་ལ་ཟེར།</translation>
    </message>
    <message>
        <location filename="../widget/kmenu.cpp" line="566"/>
        <source>Subtitle select</source>
        <translation>ཡིག་བརྙན་གདམ་གསེས་བྱེད་པ།</translation>
    </message>
    <message>
        <location filename="../widget/kmenu.cpp" line="571"/>
        <source>No subtitle</source>
        <translation>ཡིག་བརྙན་མེད་པ།</translation>
    </message>
    <message>
        <location filename="../widget/kmenu.cpp" line="585"/>
        <source>Match subtitle</source>
        <translation>ཆ་འགྲིག་ཡིག་བརྙན་</translation>
    </message>
    <message>
        <location filename="../widget/kmenu.cpp" line="590"/>
        <source>Search subtitle</source>
        <translation>ཡིག་བརྙན་འཚོལ་བཤེར་བྱ་དགོས།</translation>
    </message>
    <message>
        <location filename="../widget/kmenu.cpp" line="595"/>
        <source>Subtitle set</source>
        <translation>ཡིག་བརྙན་ཆ་ཚང་།</translation>
    </message>
    <message>
        <location filename="../widget/kmenu.cpp" line="605"/>
        <source>Play</source>
        <translation>གཏོང་བ་</translation>
    </message>
    <message>
        <location filename="../widget/kmenu.cpp" line="609"/>
        <source>Play/Pause</source>
        <translation>རྩེད་མོ་རྩེ་བ་དང་མཚམས་འཇོག་</translation>
    </message>
    <message>
        <location filename="../widget/kmenu.cpp" line="615"/>
        <source>volume up</source>
        <translation>གྲངས་འབོར་འཕར་སྣོན་བྱུང་བ</translation>
    </message>
    <message>
        <location filename="../widget/kmenu.cpp" line="621"/>
        <source>volume down</source>
        <translation>བོངས་ཚད་མར་ཆག་པ།</translation>
    </message>
    <message>
        <location filename="../widget/kmenu.cpp" line="627"/>
        <source>forward</source>
        <translation>མདུན་དུ་སྐྱོད་པ་</translation>
    </message>
    <message>
        <location filename="../widget/kmenu.cpp" line="633"/>
        <source>backward</source>
        <translation>རྗེས་ལུས་ཐེབས་པ།</translation>
    </message>
    <message>
        <location filename="../widget/kmenu.cpp" line="645"/>
        <source>setup</source>
        <translation>སྒྲིག་འཛུགས་བྱེད་པ།</translation>
    </message>
    <message>
        <location filename="../widget/kmenu.cpp" line="656"/>
        <source>Media info</source>
        <translation>སྨྱན་སྦྱོར་གྱི་ཆ་འཕྲིན།</translation>
    </message>
</context>
<context>
    <name>KylinUI::MessageBox</name>
    <message>
        <location filename="../widget/messagebox.cpp" line="92"/>
        <source>Cancel</source>
        <translation>ཕྱིར་འཐེན།</translation>
    </message>
    <message>
        <location filename="../widget/messagebox.cpp" line="96"/>
        <source>Ok</source>
        <translation>འགྲིགས།</translation>
    </message>
</context>
<context>
    <name>ListLoopMenu</name>
    <message>
        <location filename="../widget/kmenu.cpp" line="874"/>
        <source>One Loop</source>
        <translation>འཁོར་སྐྱོད་ཐེངས་གཅིག</translation>
    </message>
    <message>
        <location filename="../widget/kmenu.cpp" line="879"/>
        <source>List loop</source>
        <translation>རེའུ་མིག་འཁོར་སྐྱོད་བྱེད་བཞིན</translation>
    </message>
    <message>
        <location filename="../widget/kmenu.cpp" line="884"/>
        <source>Random</source>
        <translation>སྐབས་བསྟུན་ཁྱབ་གཏོང་</translation>
    </message>
    <message>
        <location filename="../widget/kmenu.cpp" line="889"/>
        <source>Sequence</source>
        <translation>གོ་རིམ།</translation>
    </message>
</context>
<context>
    <name>MainWidget</name>
    <message>
        <source>Form</source>
        <translation type="vanished">Form</translation>
    </message>
    <message>
        <source>Video Player</source>
        <translation type="vanished">བརྙན་ཕབ་འཕྲུལ་འཁོར།</translation>
    </message>
    <message>
        <source>Video Player Choose a file</source>
        <translation type="vanished">བརྙན་ཕབ་འཕྲུལ་འཁོར་གྱིས་ཡིག་ཆ་ཞིག་བདམས་</translation>
    </message>
    <message>
        <source>Multimedia</source>
        <translation type="vanished">སྨྱན་སྦྱོར་མང་པོ།</translation>
    </message>
    <message>
        <source>Video</source>
        <translation type="vanished">བརྙན་ཕབ།</translation>
    </message>
    <message>
        <source>Audio</source>
        <translation type="vanished">སྒྲ་ཕབ།</translation>
    </message>
    <message>
        <source>Video Player Choose a directory</source>
        <translation type="vanished">བརྙན་ཕབ་འཕྲུལ་འཁོར་གྱིས་དཀར་ཆག་འདེམས་པ།</translation>
    </message>
    <message>
        <source>video player</source>
        <translation type="vanished">བརྙན་ཕབ་འཕྲུལ་འཁོར།</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../mainwindow.cpp" line="93"/>
        <source>/Video</source>
        <translation>བརྙན་ཕབ་</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="243"/>
        <location filename="../mainwindow.cpp" line="449"/>
        <location filename="../mainwindow.cpp" line="853"/>
        <source>Video Player</source>
        <translation>བརྙན་ཕབ་འཕྲུལ་འཁོར།</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="925"/>
        <source>Video Player Choose a file</source>
        <translation>བརྙན་ཕབ་འཕྲུལ་འཁོར་གྱིས་ཡིག་ཆ་ཞིག་བདམས་</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="927"/>
        <source>Multimedia</source>
        <translation>སྨྱན་སྦྱོར་མང་པོ།</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="930"/>
        <source>Video</source>
        <translation>བརྙན་ཕབ།</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="933"/>
        <source>Audio</source>
        <translation>སྒྲ་ཕབ།</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1006"/>
        <source>Video Player Choose a directory</source>
        <translation>བརྙན་ཕབ་འཕྲུལ་འཁོར་གྱིས་དཀར་ཆག་འདེམས་པ།</translation>
    </message>
</context>
<context>
    <name>MarkListItem</name>
    <message>
        <location filename="../widget/playlistwidget.cpp" line="244"/>
        <source>Video Player</source>
        <translation>བརྙན་ཕབ་འཕྲུལ་འཁོར།</translation>
    </message>
    <message>
        <location filename="../widget/playlistwidget.cpp" line="244"/>
        <location filename="../widget/playlistwidget.cpp" line="248"/>
        <source>File not exist!</source>
        <translation>ཡིག་ཆ་མེད་པ་རེད།!</translation>
    </message>
</context>
<context>
    <name>MediaInfoDialog</name>
    <message>
        <location filename="../widget/mediainfodialog.ui" line="14"/>
        <source>Dialog</source>
        <translation>Dialog</translation>
    </message>
    <message>
        <location filename="../widget/mediainfodialog.ui" line="74"/>
        <source>video player</source>
        <translation>བརྙན་ཕབ་འཕྲུལ་འཁོར།</translation>
    </message>
    <message>
        <location filename="../widget/mediainfodialog.ui" line="127"/>
        <source>ok</source>
        <translation>འགྲིགས།</translation>
    </message>
    <message>
        <location filename="../widget/mediainfodialog.cpp" line="55"/>
        <source>media info</source>
        <translation>སྨྱན་སྦྱོར་གྱི་ཆ་འཕྲིན།</translation>
    </message>
    <message>
        <location filename="../widget/mediainfodialog.cpp" line="56"/>
        <source>title:</source>
        <translation>ཁ་བྱང་ནི།:</translation>
    </message>
    <message>
        <location filename="../widget/mediainfodialog.cpp" line="57"/>
        <source>type:</source>
        <translation>རིགས་དབྱིབས་ནི།:</translation>
    </message>
    <message>
        <location filename="../widget/mediainfodialog.cpp" line="58"/>
        <source>size:</source>
        <translation>ཆེ་ཆུང་ནི།:</translation>
    </message>
    <message>
        <location filename="../widget/mediainfodialog.cpp" line="59"/>
        <source>duration:</source>
        <translation>དུས་ཡུན་ནི།:</translation>
    </message>
    <message>
        <location filename="../widget/mediainfodialog.cpp" line="60"/>
        <source>path:</source>
        <translation>འགྲོ་ལམ་ནི།:</translation>
    </message>
</context>
<context>
    <name>MiniModeShade</name>
    <message>
        <location filename="../widget/minimodeshade.cpp" line="51"/>
        <source>pause</source>
        <translation>མཚམས་འཇོག་པ།</translation>
    </message>
    <message>
        <location filename="../widget/minimodeshade.cpp" line="55"/>
        <source>play</source>
        <translation>རྩེད་མོ་རྩེ་བ།</translation>
    </message>
    <message>
        <location filename="../widget/minimodeshade.cpp" line="94"/>
        <source>close</source>
        <translation>སྒོ་རྒྱག་པ།</translation>
    </message>
    <message>
        <location filename="../widget/minimodeshade.cpp" line="103"/>
        <source>normal mode</source>
        <translation>རྒྱུན་ལྡན་གྱི་རྣམ་པ</translation>
    </message>
</context>
<context>
    <name>MpvCore</name>
    <message>
        <location filename="../core/mpvcore.cpp" line="1321"/>
        <source>Pictures</source>
        <translation>པར་རིས།</translation>
    </message>
    <message>
        <location filename="../core/mpvcore.cpp" line="1348"/>
        <source>default</source>
        <translation>ཁ་ཆད་དང་འགལ་</translation>
    </message>
    <message>
        <location filename="../core/mpvcore.cpp" line="1359"/>
        <source>auto</source>
        <translation>རང་འགུལ་གྱིས་རླངས་</translation>
    </message>
    <message>
        <location filename="../core/mpvcore.cpp" line="194"/>
        <source>File</source>
        <translation>ཡིག་ཆ།</translation>
    </message>
    <message>
        <location filename="../core/mpvcore.cpp" line="195"/>
        <source>Title</source>
        <translation>ཁ་བྱང་།</translation>
    </message>
    <message>
        <location filename="../core/mpvcore.cpp" line="196"/>
        <source>File size</source>
        <translation>ཡིག་ཆའི་ཆེ་ཆུང་།</translation>
    </message>
    <message>
        <location filename="../core/mpvcore.cpp" line="197"/>
        <source>Date created</source>
        <translation>གསར་སྐྲུན་བྱས་པའི་དུས་ཚོད།</translation>
    </message>
    <message>
        <location filename="../core/mpvcore.cpp" line="198"/>
        <source>Media length</source>
        <translation>སྨྱན་སྦྱོར་གྱི་རིང་ཚད</translation>
    </message>
    <message>
        <location filename="../core/mpvcore.cpp" line="200"/>
        <source>Video (x%0)</source>
        <translation>བརྙན་ཕབ(x%0)</translation>
    </message>
    <message>
        <location filename="../core/mpvcore.cpp" line="201"/>
        <source>Video Output</source>
        <translation>བརྙན་ཕབ་ཀྱི་ཐོན་ཚད།</translation>
    </message>
    <message>
        <location filename="../core/mpvcore.cpp" line="202"/>
        <source>Resolution</source>
        <translation>གྲོས་ཆོད།</translation>
    </message>
    <message>
        <location filename="../core/mpvcore.cpp" line="205"/>
        <source>FPS</source>
        <translation>FPS</translation>
    </message>
    <message>
        <location filename="../core/mpvcore.cpp" line="206"/>
        <location filename="../core/mpvcore.cpp" line="212"/>
        <source>Bitrate</source>
        <translation>སོ་བཏབ་པ།</translation>
    </message>
    <message>
        <location filename="../core/mpvcore.cpp" line="206"/>
        <location filename="../core/mpvcore.cpp" line="212"/>
        <source>%0 kbps</source>
        <translation>%0 kbps</translation>
    </message>
    <message>
        <location filename="../core/mpvcore.cpp" line="208"/>
        <source>Audio (x%0)</source>
        <translation>སྒྲ་གདངས་(x%0)</translation>
    </message>
    <message>
        <location filename="../core/mpvcore.cpp" line="209"/>
        <source>Audio Output</source>
        <translation>སྒྲ་ཕབ་བརྙན་ཕབ།</translation>
    </message>
    <message>
        <location filename="../core/mpvcore.cpp" line="210"/>
        <source>Sample Rate</source>
        <translation>དཔེ་མཚོན་ཐོན་རྫས་ཀྱི་བ</translation>
    </message>
    <message>
        <location filename="../core/mpvcore.cpp" line="211"/>
        <source>Channels</source>
        <translation>ཐབས་ལམ།</translation>
    </message>
    <message>
        <location filename="../core/mpvcore.cpp" line="216"/>
        <source>Chapters</source>
        <translation>ལེའུ་སོ་སོ།</translation>
    </message>
    <message>
        <location filename="../core/mpvcore.cpp" line="225"/>
        <source>Metadata</source>
        <translation>གཞི་གྲངས།</translation>
    </message>
    <message>
        <location filename="../core/mpvcore.cpp" line="652"/>
        <source>Stereo</source>
        <translation>སྒྲ་སྐྱེད་འཕྲུལ་འཁོར།</translation>
    </message>
    <message>
        <location filename="../core/mpvcore.cpp" line="658"/>
        <source>Left Channel</source>
        <translation>གཡོན་ཕྱོགས་ཀྱི་བགྲོད་ལམ།</translation>
    </message>
    <message>
        <location filename="../core/mpvcore.cpp" line="667"/>
        <source>Right Channel</source>
        <translation>ཡང་དག་པའི་བགྲོད་ལམ།</translation>
    </message>
    <message>
        <location filename="../core/mpvcore.cpp" line="719"/>
        <location filename="../core/mpvcore.cpp" line="730"/>
        <source>brightness : %1</source>
        <translation>གསལ་ཆ། %1</translation>
    </message>
    <message>
        <location filename="../core/mpvcore.cpp" line="951"/>
        <location filename="../core/mpvcore.cpp" line="958"/>
        <source>subtitle delay : %1s</source>
        <translation>ཡིག་བརྙན་གྱི་འགོར་འགྱངས་ནི་%1s</translation>
    </message>
    <message>
        <location filename="../core/mpvcore.cpp" line="975"/>
        <source>Add mark error</source>
        <translation>རྟགས་ཀྱི་ནོར་འཁྲུལ་ཁ་སྣོན་</translation>
    </message>
    <message>
        <location filename="../core/mpvcore.cpp" line="1015"/>
        <source>Add mark ok</source>
        <translation>རྟགས་བརྒྱབ་ན་འགྲིག་གི་རེད།</translation>
    </message>
    <message>
        <location filename="../core/mpvcore.cpp" line="828"/>
        <source>restore frame</source>
        <translation>སླར་གསོ་བྱེད་པའི་སྒྲོམ་གཞི</translation>
    </message>
    <message>
        <location filename="../core/mpvcore.cpp" line="861"/>
        <source>Horizontal Flip: </source>
        <translation>འཕྲེད་ཕྱོགས་ནས་ཕར་འགྲོ་ཚུར་འོང་བྱེད་ </translation>
    </message>
    <message>
        <location filename="../core/mpvcore.cpp" line="861"/>
        <location filename="../core/mpvcore.cpp" line="875"/>
        <source>close</source>
        <translation>སྒོ་རྒྱག་པ།</translation>
    </message>
    <message>
        <location filename="../core/mpvcore.cpp" line="861"/>
        <location filename="../core/mpvcore.cpp" line="875"/>
        <source>open</source>
        <translation>སྒོ་ཕྱེ་བ།</translation>
    </message>
    <message>
        <location filename="../core/mpvcore.cpp" line="875"/>
        <source>Vertical Flip: </source>
        <translation>དྲང་འཕྱང་གི་ལྡོག་ཕྱོགས་ནི། </translation>
    </message>
    <message>
        <location filename="../core/mpvcore.cpp" line="1024"/>
        <source>ScreenShot OK</source>
        <translation>བརྙན་ཤེལ་གྱི་པར་རིས་ཡག་པོ་</translation>
    </message>
    <message>
        <location filename="../core/mpvcore.cpp" line="1026"/>
        <source>ScreenShot Failed, folder has no write permission or folder not exit.</source>
        <translation>&quot;</translation>
    </message>
    <message>
        <location filename="../core/mpvcore.cpp" line="86"/>
        <source>File:</source>
        <translation>ཡིག་ཆ་འདི་ལྟ་སྟེ།:</translation>
    </message>
    <message>
        <location filename="../core/mpvcore.cpp" line="88"/>
        <source>Video:</source>
        <translation>བརྙན་ཕབ་:</translation>
    </message>
    <message>
        <location filename="../core/mpvcore.cpp" line="89"/>
        <source>Resolution:</source>
        <translation>གྲོས་ཆོད།:</translation>
    </message>
    <message>
        <location filename="../core/mpvcore.cpp" line="90"/>
        <source>fps:</source>
        <translation>fps:</translation>
    </message>
    <message>
        <location filename="../core/mpvcore.cpp" line="91"/>
        <location filename="../core/mpvcore.cpp" line="97"/>
        <source>Bitrate:</source>
        <translation>སོ་བཏབ་པ་གཤམ་གསལ།:</translation>
    </message>
    <message>
        <location filename="../core/mpvcore.cpp" line="94"/>
        <source>Audio:</source>
        <translation>སྒྲ་ཕབ་:</translation>
    </message>
    <message>
        <location filename="../core/mpvcore.cpp" line="95"/>
        <source>Sample Rate:</source>
        <translation>དཔེ་མཚོན་ཐོན་རྫས་ཀྱི་བསྡུར་ཚད:</translation>
    </message>
    <message>
        <location filename="../core/mpvcore.cpp" line="96"/>
        <source>Channels:</source>
        <translation>ཐབས་ལམ་ནི།:</translation>
    </message>
    <message>
        <location filename="../core/mpvcore.cpp" line="1156"/>
        <location filename="../core/mpvcore.cpp" line="1492"/>
        <source>volume : %1</source>
        <translation>བོངས་ཚད: %1</translation>
    </message>
    <message>
        <location filename="../core/mpvcore.cpp" line="1161"/>
        <location filename="../core/mpvcore.cpp" line="1525"/>
        <source>Mute</source>
        <translation>སྐད་ཆ་མི་བཤད་པ།</translation>
    </message>
    <message>
        <location filename="../core/mpvcore.cpp" line="1161"/>
        <location filename="../core/mpvcore.cpp" line="1525"/>
        <source>Cancel Mute</source>
        <translation>མེད་པར་བཟོ་བ།</translation>
    </message>
    <message>
        <location filename="../core/mpvcore.cpp" line="1224"/>
        <source>Buffering...</source>
        <translation>བར་ཆད་བྱུང་བ་ ...</translation>
    </message>
    <message>
        <location filename="../core/mpvcore.cpp" line="1500"/>
        <source>speed : %1x</source>
        <translation>མྱུར་ཚད: %1x</translation>
    </message>
    <message>
        <location filename="../core/mpvcore.cpp" line="1588"/>
        <source>Playing</source>
        <translation>རྩེད་འཇོར་རོལ་བ།</translation>
    </message>
    <message>
        <location filename="../core/mpvcore.cpp" line="1599"/>
        <source>Paused</source>
        <translation>མཚམས་བཞག་པ།</translation>
    </message>
    <message>
        <location filename="../core/mpvcore.cpp" line="1644"/>
        <location filename="../core/mpvcore.cpp" line="1649"/>
        <source>subtitle : </source>
        <translation>ཡིག་བརྙན་གྱི་ཡིག་བརྙན་ནི ། :</translation>
    </message>
</context>
<context>
    <name>PlayListItem</name>
    <message>
        <location filename="../widget/playlistwidget.cpp" line="655"/>
        <source>File not exist!</source>
        <translation>ཡིག་ཆ་མེད་པ་རེད།</translation>
    </message>
</context>
<context>
    <name>PlayListItemMenu</name>
    <message>
        <location filename="../widget/kmenu.cpp" line="1234"/>
        <source>Remove selected</source>
        <translation>བདམས་ཟིན་པའི་གནས་དབྱུང་</translation>
    </message>
    <message>
        <location filename="../widget/kmenu.cpp" line="1238"/>
        <source>Remove invalid</source>
        <translation>གོ་མི་ཆོད་པའི་གནས་ཚུལ་མེད་པར་</translation>
    </message>
    <message>
        <location filename="../widget/kmenu.cpp" line="1242"/>
        <source>Clear list</source>
        <translation>གསལ་པོར་འགོད་དགོས་</translation>
    </message>
    <message>
        <location filename="../widget/kmenu.cpp" line="1246"/>
        <source>Open folder</source>
        <translation>ཁ་ཕྱེ་བའི་ཡིག་སྣོད</translation>
    </message>
    <message>
        <location filename="../widget/kmenu.cpp" line="1250"/>
        <source>Sort</source>
        <translation>རིགས་འབྱེད་པ།</translation>
    </message>
    <message>
        <location filename="../widget/kmenu.cpp" line="1253"/>
        <source>Sort by name</source>
        <translation>རང་མིང་མི་འགོད་པའི་སྒོ་ནས་</translation>
    </message>
    <message>
        <location filename="../widget/kmenu.cpp" line="1256"/>
        <source>Sort by type</source>
        <translation>རིགས་དབྱིབས་ལྟར་རིགས་འབྱེད་པ།</translation>
    </message>
</context>
<context>
    <name>PlayListWidget</name>
    <message>
        <source>Form</source>
        <translation type="vanished">Form</translation>
    </message>
    <message>
        <location filename="../widget/playlistwidget.cpp" line="850"/>
        <location filename="../widget/playlistwidget.cpp" line="854"/>
        <location filename="../widget/playlistwidget.cpp" line="1639"/>
        <location filename="../widget/playlistwidget.cpp" line="1651"/>
        <source>Video Player</source>
        <translation>བརྙན་ཕབ་འཕྲུལ་འཁོར།</translation>
    </message>
    <message>
        <location filename="../widget/playlistwidget.cpp" line="850"/>
        <source>Are you sure you want to clear the list?</source>
        <translation>ཁྱོད་ཀྱིས་ངེས་པར་དུ་མིང་ཐོ་གཙང་བཤེར་བྱེད་དགོས་སམ།</translation>
    </message>
    <message>
        <location filename="../widget/playlistwidget.cpp" line="854"/>
        <source>The file being played will be stopped.</source>
        <translation>འདོན་སྤེལ་བྱེད་བཞིན་པའི་ཡིག་ཆ་དེ་བཀག་འགོག་བྱེད་རྒྱུ་རེད།</translation>
    </message>
    <message>
        <location filename="../widget/playlistwidget.cpp" line="1145"/>
        <source>Preview view</source>
        <translation>སྔོན་བརྡའི་ལྟ་ཚུལ།</translation>
    </message>
    <message>
        <location filename="../widget/playlistwidget.cpp" line="1158"/>
        <source>List view</source>
        <translation>མིང་ཐོའི་ལྟ་ཚུལ།</translation>
    </message>
    <message>
        <location filename="../widget/playlistwidget.cpp" line="1313"/>
        <source>Video</source>
        <translation>བརྙན་ཕབ།</translation>
    </message>
    <message>
        <location filename="../widget/playlistwidget.cpp" line="1313"/>
        <source>Marks</source>
        <translation>མཚོན་རྟགས།</translation>
    </message>
    <message>
        <location filename="../widget/playlistwidget.cpp" line="1347"/>
        <source>Add file</source>
        <translation>ཡིག་ཆ་ཁ་སྣོན་བྱེད་པ</translation>
    </message>
    <message>
        <location filename="../widget/playlistwidget.cpp" line="1348"/>
        <source>Clear list</source>
        <translation>གསལ་པོར་འགོད་དགོས་</translation>
    </message>
    <message>
        <location filename="../widget/playlistwidget.cpp" line="1463"/>
        <location filename="../widget/playlistwidget.cpp" line="1465"/>
        <source>Load file error!</source>
        <translation>ཡིག་ཚགས་ཀྱི་ནོར་འཁྲུལ་བྱུང་བ་རེད།</translation>
    </message>
    <message>
        <location filename="../widget/playlistwidget.cpp" line="1543"/>
        <source>Please add file to list ~</source>
        <translation>མིང་ཐོའི་ནང་དུ་ཡིག་ཆ་ཁ་སྣོན་བྱེད་རོགས། ~</translation>
    </message>
    <message>
        <location filename="../widget/playlistwidget.cpp" line="1558"/>
        <source>One loop</source>
        <translation>འཁོར་སྐྱོད་ཐེངས་གཅིག</translation>
    </message>
    <message>
        <location filename="../widget/playlistwidget.cpp" line="1562"/>
        <source>Sequential</source>
        <translation>Sequential</translation>
    </message>
    <message>
        <location filename="../widget/playlistwidget.cpp" line="1566"/>
        <source>List loop</source>
        <translation>རེའུ་མིག་འཁོར་སྐྱོད་བྱེད་བཞིན</translation>
    </message>
    <message>
        <location filename="../widget/playlistwidget.cpp" line="1570"/>
        <source>Random</source>
        <translation>སྐབས་བསྟུན་ཁྱབ་གཏོང་</translation>
    </message>
    <message>
        <location filename="../widget/playlistwidget.cpp" line="1134"/>
        <location filename="../widget/playlistwidget.cpp" line="1639"/>
        <location filename="../widget/playlistwidget.cpp" line="1643"/>
        <location filename="../widget/playlistwidget.cpp" line="1651"/>
        <location filename="../widget/playlistwidget.cpp" line="1655"/>
        <source>File not exist!</source>
        <translation>ཡིག་ཆ་མེད་པ་རེད།</translation>
    </message>
</context>
<context>
    <name>PreviewWidget</name>
    <message>
        <source>Form</source>
        <translation type="vanished">Form</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../global/functions.cpp" line="109"/>
        <source>Model name</source>
        <translation>དཔེ་དབྱིབས་ཀྱི་མིང་།</translation>
    </message>
</context>
<context>
    <name>SetUpDialog</name>
    <message>
        <location filename="../widget/setup/setupdialog.ui" line="14"/>
        <source>Dialog</source>
        <translation>Dialog</translation>
    </message>
    <message>
        <location filename="../widget/setup/setupdialog.ui" line="225"/>
        <source>Cancel</source>
        <translation>ཕྱིར་འཐེན།</translation>
    </message>
    <message>
        <location filename="../widget/setup/setupdialog.ui" line="232"/>
        <source>OK</source>
        <translation>འགྲིགས།</translation>
    </message>
    <message>
        <location filename="../widget/setup/setupdialog.cpp" line="185"/>
        <source>Video Player Set up</source>
        <translation>བརྙན་ཕབ་འཕྲུལ་ཆས་བཙུགས་པ།</translation>
    </message>
    <message>
        <location filename="../widget/setup/setupdialog.cpp" line="230"/>
        <source>Setup</source>
        <translation>སྒྲིག་འཛུགས་བྱེད་པ།</translation>
    </message>
    <message>
        <location filename="../widget/setup/setupdialog.cpp" line="258"/>
        <source>System</source>
        <translation>ལམ་ལུགས།</translation>
    </message>
    <message>
        <location filename="../widget/setup/setupdialog.cpp" line="259"/>
        <source>Play</source>
        <translation>གཏོང་བ་</translation>
    </message>
    <message>
        <location filename="../widget/setup/setupdialog.cpp" line="260"/>
        <source>ScreenShot</source>
        <translation>བརྙན་ཤེལ་གྱི་པར་རིས།</translation>
    </message>
    <message>
        <location filename="../widget/setup/setupdialog.cpp" line="261"/>
        <source>Subtitle</source>
        <translation>ཡིག་བརྙན་གྱི་ཡིག་བརྙན།</translation>
    </message>
    <message>
        <location filename="../widget/setup/setupdialog.cpp" line="262"/>
        <source>Audio</source>
        <translation>སྒྲ་ཕབ།</translation>
    </message>
    <message>
        <location filename="../widget/setup/setupdialog.cpp" line="263"/>
        <source>Codec</source>
        <translation>ཨང་ཀི་ཨང་ཀི།</translation>
    </message>
    <message>
        <location filename="../widget/setup/setupdialog.cpp" line="264"/>
        <source>Shortcut</source>
        <translation>མྱུར་བགྲོད་གཞུང་ལམ།</translation>
    </message>
</context>
<context>
    <name>SetupCodec</name>
    <message>
        <source>Form</source>
        <translation type="vanished">Form</translation>
    </message>
    <message>
        <source>Demux</source>
        <translation type="vanished">གདོན་འདྲེ།</translation>
    </message>
    <message>
        <location filename="../widget/setup/setupcodec.cpp" line="51"/>
        <source>Video decoder</source>
        <translation>བརྙན་ཕབ་ཀྱི་སྒྲིག་ཆས།</translation>
    </message>
    <message>
        <source>Audio decoder</source>
        <translation type="vanished">སྒྲ་ཕབ་འཕྲུལ་ཆས།</translation>
    </message>
    <message>
        <location filename="../widget/setup/setupcodec.cpp" line="38"/>
        <source>default</source>
        <translation>ཁ་ཆད་དང་འགལ་</translation>
    </message>
    <message>
        <location filename="../widget/setup/setupcodec.cpp" line="38"/>
        <source>no</source>
        <translation>མིན།</translation>
    </message>
    <message>
        <location filename="../widget/setup/setupcodec.cpp" line="42"/>
        <source>Video output</source>
        <translation>བརྙན་ཕབ་ཀྱི་ཐོན་ཚད།</translation>
    </message>
    <message>
        <location filename="../widget/setup/setupcodec.cpp" line="43"/>
        <source>auto</source>
        <translation>རང་འགུལ་གྱིས་རླངས་</translation>
    </message>
    <message>
        <location filename="../widget/setup/setupcodec.cpp" line="53"/>
        <source>Decode threads</source>
        <translation>ཨང་སྒྲིག་སྐུད་པ།</translation>
    </message>
</context>
<context>
    <name>SetupPlay</name>
    <message>
        <source>Form</source>
        <translation type="vanished">Form</translation>
    </message>
    <message>
        <location filename="../widget/setup/setupplay.cpp" line="88"/>
        <source>Set fullscreen when open video</source>
        <translation>བརྙན་ཕབ་བྱེད་སྐབས་བརྙན་ཤེལ་ཆ་ཚང་ཞིག་གཏན་འཁེལ</translation>
    </message>
    <message>
        <location filename="../widget/setup/setupplay.cpp" line="92"/>
        <source>Clear play list on exit</source>
        <translation>ཕྱིར་འཐེན་བྱ་རྒྱུའི་སྐོར་གྱི་འགྲན་བསྡུར་གྱི་</translation>
    </message>
    <message>
        <location filename="../widget/setup/setupplay.cpp" line="96"/>
        <source>Automatically plays from where the file was last stopped</source>
        <translation>རང་འགུལ་གྱིས་ཡིག་ཆ་དེ་ཆེས་མཐའ་མཇུག་གི་བཀག་འགོག་བྱེད་ས་ནས་འདོན་སྤེལ་བྱས།</translation>
    </message>
    <message>
        <location filename="../widget/setup/setupplay.cpp" line="100"/>
        <source>Automatically find associated files to play</source>
        <translation>རང་འགུལ་གྱིས་འབྲེལ་ཡོད་ཡིག་ཆ་བཙལ་ནས་རྩེད་མོ་རྩེ་བཞིན་ཡོད།</translation>
    </message>
</context>
<context>
    <name>SetupScreenshot</name>
    <message>
        <source>Form</source>
        <translation type="vanished">Form</translation>
    </message>
    <message>
        <location filename="../widget/setup/setupscreenshot.cpp" line="126"/>
        <source>Only save to clipboard</source>
        <translation>གྲོན་ཆུང་བྱས་ནས་པང་ལེབ་ཁོ་ནར་ཉར་ཚགས་</translation>
    </message>
    <message>
        <location filename="../widget/setup/setupscreenshot.cpp" line="130"/>
        <source>Save to file</source>
        <translation>ཉར་ཚགས་བྱས་ནས་ཡིག་ཚགས་སུ་</translation>
    </message>
    <message>
        <location filename="../widget/setup/setupscreenshot.cpp" line="138"/>
        <source>save path</source>
        <translation>གྲོན་ཆུང་གི་ལམ་བུ།</translation>
    </message>
    <message>
        <source>browse</source>
        <translation type="vanished">རགས་ལྟ།</translation>
    </message>
    <message>
        <location filename="../widget/setup/setupscreenshot.cpp" line="155"/>
        <source>save type</source>
        <translation>ཉར་ཚགས་བྱས་པའི་རིགས་དབྱིབས</translation>
    </message>
    <message>
        <location filename="../widget/setup/setupscreenshot.cpp" line="167"/>
        <source>Screenshot according to the current screen size</source>
        <translation>མིག་སྔའི་བརྙན་ཤེལ་གྱི་ཆེ་ཆུང་ལ་གཞིགས་ནས་པར་ལེན་བྱས་པ།</translation>
    </message>
    <message>
        <location filename="../widget/setup/setupscreenshot.cpp" line="61"/>
        <source>Pictures</source>
        <translation>པར་རིས།</translation>
    </message>
    <message>
        <location filename="../widget/setup/setupscreenshot.cpp" line="144"/>
        <source>browser</source>
        <translation>རགས་ལྟ།</translation>
    </message>
    <message>
        <location filename="../widget/setup/setupscreenshot.cpp" line="221"/>
        <source>Video Player Choose a directory</source>
        <translation>བརྙན་ཕབ་འཕྲུལ་འཁོར་གྱིས་དཀར་ཆག་འདེམས་པ།</translation>
    </message>
</context>
<context>
    <name>SetupShortcut</name>
    <message>
        <source>Form</source>
        <translation type="vanished">Form</translation>
    </message>
    <message>
        <location filename="../widget/setup/setupshortcut.cpp" line="215"/>
        <source>file</source>
        <translation>ཡིག་ཆ།</translation>
    </message>
    <message>
        <location filename="../widget/setup/setupshortcut.cpp" line="216"/>
        <source>play</source>
        <translation>རྩེད་མོ་རྩེ་བ།</translation>
    </message>
    <message>
        <location filename="../widget/setup/setupshortcut.cpp" line="217"/>
        <source>image</source>
        <translation>པར་རིས།</translation>
    </message>
    <message>
        <location filename="../widget/setup/setupshortcut.cpp" line="218"/>
        <source>audio</source>
        <translation>སྒྲ་ཟློས།</translation>
    </message>
    <message>
        <location filename="../widget/setup/setupshortcut.cpp" line="219"/>
        <source>sub</source>
        <translation>ཡན་ལག་རུ་ཁག</translation>
    </message>
    <message>
        <location filename="../widget/setup/setupshortcut.cpp" line="220"/>
        <source>other</source>
        <translation>གཞན་དག</translation>
    </message>
    <message>
        <location filename="../widget/setup/setupshortcut.cpp" line="276"/>
        <source>open file</source>
        <translation>ཁ་ཕྱེ་བའི་ཡིག་ཆ།</translation>
    </message>
    <message>
        <location filename="../widget/setup/setupshortcut.cpp" line="277"/>
        <source>open dir</source>
        <translation>ཁ་ཕྱེས་པའི་ཉིན་ཐོ།</translation>
    </message>
    <message>
        <location filename="../widget/setup/setupshortcut.cpp" line="278"/>
        <source>prev file</source>
        <translation>prev ཡིག་ཆ།</translation>
    </message>
    <message>
        <location filename="../widget/setup/setupshortcut.cpp" line="279"/>
        <source>next file</source>
        <translation>རྗེས་མའི་ཡིག་ཆ།</translation>
    </message>
    <message>
        <location filename="../widget/setup/setupshortcut.cpp" line="302"/>
        <source>play/pause</source>
        <translation>རྩེད་མོ་རྩེ་བ་དང་མཚམས་འཇོག་</translation>
    </message>
    <message>
        <location filename="../widget/setup/setupshortcut.cpp" line="303"/>
        <source>speed up</source>
        <translation>མྱུར་ཚད་ཇེ་མགྱོགས་སུ་གཏོང</translation>
    </message>
    <message>
        <location filename="../widget/setup/setupshortcut.cpp" line="304"/>
        <source>speed down</source>
        <translation>མྱུར་ཚད་ཇེ་མགྱོགས་སུ་</translation>
    </message>
    <message>
        <location filename="../widget/setup/setupshortcut.cpp" line="305"/>
        <source>speed normal</source>
        <translation>མྱུར་ཚད་རྒྱུན་ལྡན་ལྟར</translation>
    </message>
    <message>
        <location filename="../widget/setup/setupshortcut.cpp" line="306"/>
        <source>forword</source>
        <translation>རལ་གྲི།</translation>
    </message>
    <message>
        <location filename="../widget/setup/setupshortcut.cpp" line="307"/>
        <source>backword</source>
        <translation>ཡི་གེ་རྗེས་མ།</translation>
    </message>
    <message>
        <location filename="../widget/setup/setupshortcut.cpp" line="308"/>
        <source>forward 30s</source>
        <translation>མདུན་སྐྱོད་ཀྱི་ལོ་30</translation>
    </message>
    <message>
        <location filename="../widget/setup/setupshortcut.cpp" line="309"/>
        <source>backword 30s</source>
        <translation>རྒྱབ་ཀྱི་ཡི་གེ་30</translation>
    </message>
    <message>
        <location filename="../widget/setup/setupshortcut.cpp" line="310"/>
        <source>insert bookmark</source>
        <translation>དཔེ་ཆའི་མཚོན་རྟགས་ནང་འཇུག་དགོས།</translation>
    </message>
    <message>
        <location filename="../widget/setup/setupshortcut.cpp" line="334"/>
        <source>fullscreen</source>
        <translation>བརྙན་ཤེལ་ཧྲིལ་བོ།</translation>
    </message>
    <message>
        <location filename="../widget/setup/setupshortcut.cpp" line="335"/>
        <source>mini mode</source>
        <translation>ཁུ་བསྡུ་བྱེད་སྟངས་</translation>
    </message>
    <message>
        <location filename="../widget/setup/setupshortcut.cpp" line="336"/>
        <source>to top</source>
        <translation>གོང་ནས་འོག་བར་དུ།</translation>
    </message>
    <message>
        <location filename="../widget/setup/setupshortcut.cpp" line="337"/>
        <source>screenshot</source>
        <translation>བརྙན་ཤེལ་གྱི་པར་རིས།</translation>
    </message>
    <message>
        <location filename="../widget/setup/setupshortcut.cpp" line="339"/>
        <source>light up</source>
        <translation>འོད་ཆེམ་ཆེམ་དུ་</translation>
    </message>
    <message>
        <location filename="../widget/setup/setupshortcut.cpp" line="340"/>
        <source>light down</source>
        <translation>འོད་སྣང་འཕྲོ་བ།</translation>
    </message>
    <message>
        <location filename="../widget/setup/setupshortcut.cpp" line="341"/>
        <source>forward rotate</source>
        <translation>མདུན་སྐྱོད་ཀྱི་འཁོར་སྐྱོད།</translation>
    </message>
    <message>
        <location filename="../widget/setup/setupshortcut.cpp" line="342"/>
        <source>backward rotate</source>
        <translation>རྗེས་ལུས་ཀྱི་འཁོར་སྐྱོད།</translation>
    </message>
    <message>
        <location filename="../widget/setup/setupshortcut.cpp" line="343"/>
        <source>horizontal flip</source>
        <translation>འཕྲེད་ཕྱོགས་ཀྱི་འདྲུད་འཐེན་འཕྲུལ་</translation>
    </message>
    <message>
        <location filename="../widget/setup/setupshortcut.cpp" line="344"/>
        <source>vertical flip</source>
        <translation>གཞུང་ཕྱོགས་ནས་ཕར་འགྲོ་ཚུར་འོང་བྱེད</translation>
    </message>
    <message>
        <location filename="../widget/setup/setupshortcut.cpp" line="369"/>
        <source>volume up</source>
        <translation>གྲངས་འབོར་འཕར་སྣོན་བྱུང་བ</translation>
    </message>
    <message>
        <location filename="../widget/setup/setupshortcut.cpp" line="370"/>
        <source>volume down</source>
        <translation>བོངས་ཚད་མར་ཆག་པ།</translation>
    </message>
    <message>
        <location filename="../widget/setup/setupshortcut.cpp" line="371"/>
        <source>mute</source>
        <translation>སྐད་ཆ་མི་བཤད་པ།</translation>
    </message>
    <message>
        <location filename="../widget/setup/setupshortcut.cpp" line="372"/>
        <source>audio next</source>
        <translation>གོམ་སྟབས་རྗེས་མར་སྒྲ་ཕབ</translation>
    </message>
    <message>
        <location filename="../widget/setup/setupshortcut.cpp" line="373"/>
        <source>default channel</source>
        <translation>default ཐབས་ལམ།</translation>
    </message>
    <message>
        <location filename="../widget/setup/setupshortcut.cpp" line="374"/>
        <source>left channel</source>
        <translation>གཡོན་ཕྱོགས་ཀྱི་བགྲོད་ལམ།</translation>
    </message>
    <message>
        <location filename="../widget/setup/setupshortcut.cpp" line="375"/>
        <source>right channel</source>
        <translation>ཡང་དག་པའི་ཐབས་ལམ།</translation>
    </message>
    <message>
        <location filename="../widget/setup/setupshortcut.cpp" line="398"/>
        <source>sub load</source>
        <translation>ཡན་ལག་གི་ཐེག་ཚད།</translation>
    </message>
    <message>
        <location filename="../widget/setup/setupshortcut.cpp" line="399"/>
        <source>sub earlier</source>
        <translation>སྔ་མོ་ནས་ཡན་ལག་རུ་ཁག</translation>
    </message>
    <message>
        <location filename="../widget/setup/setupshortcut.cpp" line="400"/>
        <source>sub later</source>
        <translation>རྗེས་སུ་ཡན་ལག་རུ་ཁག</translation>
    </message>
    <message>
        <location filename="../widget/setup/setupshortcut.cpp" line="401"/>
        <source>sub up</source>
        <translation>ཡན་ལག་རུ་ཁག</translation>
    </message>
    <message>
        <location filename="../widget/setup/setupshortcut.cpp" line="402"/>
        <source>sub down</source>
        <translation>འོག་ནས་མར་ཕབ་པ།</translation>
    </message>
    <message>
        <location filename="../widget/setup/setupshortcut.cpp" line="403"/>
        <source>sub next</source>
        <translation>གོམ་སྟབས་རྗེས་མར་</translation>
    </message>
    <message>
        <location filename="../widget/setup/setupshortcut.cpp" line="426"/>
        <source>play list</source>
        <translation>རྩེད་འཇོར་རོལ་བའི་མིང</translation>
    </message>
    <message>
        <location filename="../widget/setup/setupshortcut.cpp" line="427"/>
        <source>setup</source>
        <translation>སྒྲིག་འཛུགས་བྱེད་པ།</translation>
    </message>
</context>
<context>
    <name>SetupSubtitle</name>
    <message>
        <source>Form</source>
        <translation type="vanished">Form</translation>
    </message>
    <message>
        <location filename="../widget/setup/setupsubtitle.cpp" line="128"/>
        <source>Sub loading</source>
        <translation>དངོས་ཟོག་སྐྱེལ་འདྲེན་བྱེད་པ།</translation>
    </message>
    <message>
        <location filename="../widget/setup/setupsubtitle.cpp" line="132"/>
        <source>Auto loading subtitles with the same name</source>
        <translation>མིང་གཅིག་མཚུངས་ཡིན་པའི་ཡིག་བརྙན་རང་འགུལ་གྱིས་ཡིག་བརྙན་ནང་འཇུག་བྱེད་པ།</translation>
    </message>
    <message>
        <location filename="../widget/setup/setupsubtitle.cpp" line="136"/>
        <source>Auto loading other subtitles in the same folder</source>
        <translation>ཡིག་སྣོད་གཅིག་གི་ནང་དུ་ཡིག་བརྙན་གཞན་པ་རང་འགུལ་གྱིས་ནང་འཇུག་བྱེད་པ།</translation>
    </message>
    <message>
        <location filename="../widget/setup/setupsubtitle.cpp" line="144"/>
        <source>Sub Path</source>
        <translation>ལམ་ཕྲན་ཆུང་ཆུང་།</translation>
    </message>
    <message>
        <location filename="../widget/setup/setupsubtitle.cpp" line="151"/>
        <source>browser</source>
        <translation>རགས་ལྟ།</translation>
    </message>
    <message>
        <source>browse</source>
        <translation type="vanished">རགས་ལྟ།</translation>
    </message>
    <message>
        <location filename="../widget/setup/setupsubtitle.cpp" line="157"/>
        <source>Font Style</source>
        <translation>ཡིག་གཟུགས་ཀྱི་ཉམས་འགྱུར།</translation>
    </message>
    <message>
        <location filename="../widget/setup/setupsubtitle.cpp" line="166"/>
        <source>Family</source>
        <translation>ཁྱིམ་ཚང་།</translation>
    </message>
    <message>
        <location filename="../widget/setup/setupsubtitle.cpp" line="183"/>
        <source>Size</source>
        <translation>ཆེ་ཆུང་།</translation>
    </message>
    <message>
        <location filename="../widget/setup/setupsubtitle.cpp" line="250"/>
        <source>Video Player Choose a directory</source>
        <translation>བརྙན་ཕབ་འཕྲུལ་འཁོར་གྱིས་དཀར་ཆག་འདེམས་པ།</translation>
    </message>
</context>
<context>
    <name>SetupSystem</name>
    <message>
        <source>Form</source>
        <translation type="vanished">Form</translation>
    </message>
    <message>
        <location filename="../widget/setup/setupsystem.cpp" line="73"/>
        <source>Window</source>
        <translation>སྒེའུ་ཁུང་།</translation>
    </message>
    <message>
        <location filename="../widget/setup/setupsystem.cpp" line="78"/>
        <source>Minimize to system tray icon</source>
        <translation>མ་ལག་གི་སྡེར་མའི་མཚོན་རྟགས་ཉུང་དུ་གཏོང་གང་ཐུབ་བྱ་དགོས།</translation>
    </message>
    <message>
        <location filename="../widget/setup/setupsystem.cpp" line="82"/>
        <source>Pause video playback when minimized</source>
        <translation>ཆེས་ཆུང་བའི་དུས་སུ་བརྙན་ཕབ་ཕྱིར་ལྡོག་བྱེད་མཚམས་འཇོག་དགོས།</translation>
    </message>
    <message>
        <location filename="../widget/setup/setupsystem.cpp" line="86"/>
        <source>After sleep/sleep/lock screen and wake up, keep playing state</source>
        <translation>གཉིད་ཁུག་པ་དང་གཉིད་ཁུག་པ། ཟྭ་བརྒྱབ་ནས་གཉིད་ལས་སད་རྗེས་མུ་མཐུད་དུ་རྩེད་འཇོར་རོལ་བའི</translation>
    </message>
    <message>
        <source>Multiple run</source>
        <translation type="vanished">ཐེངས་མང་པོར་འཁོར་སྐྱོད་བྱེད</translation>
    </message>
    <message>
        <source>Allow multiple Kylin Video to run simultaneously</source>
        <translation type="vanished">ཅིན་ལིན་གྱི་བརྙན་འཕྲིན་མང་པོ་ཞིག་དུས་གཅིག་ཏུ་འཁོར་སྐྱོད་བྱེད་དུ་འཇུག</translation>
    </message>
</context>
<context>
    <name>SetupVolume</name>
    <message>
        <source>Form</source>
        <translation type="vanished">Form</translation>
    </message>
    <message>
        <location filename="../widget/setup/setupvolume.cpp" line="84"/>
        <source>Output driver</source>
        <translation>ཐོན་སྐྱེད་ཁ་ལོ་བ།</translation>
    </message>
    <message>
        <location filename="../widget/setup/setupvolume.cpp" line="100"/>
        <source>Volume contral</source>
        <translation>བོངས་ཚད་ཀྱི་ཚོད་འཛིན་ཐེབས་པ།</translation>
    </message>
    <message>
        <location filename="../widget/setup/setupvolume.cpp" line="105"/>
        <source>Global volume</source>
        <translation>སའི་གོ་ལ་ཧྲིལ་པོའི་</translation>
    </message>
    <message>
        <location filename="../widget/setup/setupvolume.cpp" line="109"/>
        <source>Default volume standardization</source>
        <translation>ཁ་ཆད་དང་འགལ་བའི་གྲངས་འབོར་ཚད་ལྡན</translation>
    </message>
</context>
<context>
    <name>ShortCutItem</name>
    <message>
        <location filename="../widget/setup/setupshortcut.cpp" line="493"/>
        <source>Hotkey conflict</source>
        <translation>ཚ་ཚ་འུར་འུར་གྱི་གདོང་གཏུག</translation>
    </message>
</context>
<context>
    <name>ShortCutSetting</name>
    <message>
        <location filename="../global/shortcutsetting.cpp" line="43"/>
        <source>help documentation</source>
        <translation>རོགས་རམ་ཡིག་ཆ།</translation>
    </message>
    <message>
        <location filename="../global/shortcutsetting.cpp" line="44"/>
        <source>exit</source>
        <translation>ཕྱིར་འཐེན་བྱེད་པ།</translation>
    </message>
    <message>
        <location filename="../global/shortcutsetting.cpp" line="46"/>
        <source>open file</source>
        <translation>ཁ་ཕྱེ་བའི་ཡིག་ཆ།</translation>
    </message>
    <message>
        <location filename="../global/shortcutsetting.cpp" line="47"/>
        <source>open dir</source>
        <translation>ཁ་ཕྱེས་པའི་ཉིན་ཐོ།</translation>
    </message>
    <message>
        <location filename="../global/shortcutsetting.cpp" line="48"/>
        <source>prev file</source>
        <translation>prev ཡིག་ཆ།</translation>
    </message>
    <message>
        <location filename="../global/shortcutsetting.cpp" line="49"/>
        <source>next file</source>
        <translation>རྗེས་མའི་ཡིག་ཆ།</translation>
    </message>
    <message>
        <location filename="../global/shortcutsetting.cpp" line="52"/>
        <source>play/pause</source>
        <translation>རྩེད་མོ་རྩེ་བ་དང་མཚམས་འཇོག་</translation>
    </message>
    <message>
        <location filename="../global/shortcutsetting.cpp" line="53"/>
        <source>speed up</source>
        <translation>མྱུར་ཚད་ཇེ་མགྱོགས་སུ་གཏོང</translation>
    </message>
    <message>
        <location filename="../global/shortcutsetting.cpp" line="54"/>
        <source>speed down</source>
        <translation>མྱུར་ཚད་ཇེ་མགྱོགས་སུ་</translation>
    </message>
    <message>
        <location filename="../global/shortcutsetting.cpp" line="55"/>
        <source>speed normal</source>
        <translation>མྱུར་ཚད་རྒྱུན་ལྡན་ལྟར</translation>
    </message>
    <message>
        <location filename="../global/shortcutsetting.cpp" line="56"/>
        <source>forword</source>
        <translation>རལ་གྲི།</translation>
    </message>
    <message>
        <location filename="../global/shortcutsetting.cpp" line="57"/>
        <source>backword</source>
        <translation>ཡི་གེ་རྗེས་མ།</translation>
    </message>
    <message>
        <location filename="../global/shortcutsetting.cpp" line="58"/>
        <source>forward 30s</source>
        <translation>མདུན་སྐྱོད་ཀྱི་ལོ་30</translation>
    </message>
    <message>
        <location filename="../global/shortcutsetting.cpp" line="59"/>
        <source>backword 30s</source>
        <translation>རྒྱབ་ཀྱི་ཡི་གེ་30</translation>
    </message>
    <message>
        <location filename="../global/shortcutsetting.cpp" line="60"/>
        <source>insert bookmark</source>
        <translation>དཔེ་ཆའི་མཚོན་རྟགས་ནང་འཇུག་དགོས།</translation>
    </message>
    <message>
        <location filename="../global/shortcutsetting.cpp" line="61"/>
        <source>ib notes</source>
        <translation>ib ཟིན་ཐོ།</translation>
    </message>
    <message>
        <location filename="../global/shortcutsetting.cpp" line="64"/>
        <source>fullscreen</source>
        <translation>བརྙན་ཤེལ་ཧྲིལ་བོ།</translation>
    </message>
    <message>
        <location filename="../global/shortcutsetting.cpp" line="65"/>
        <source>mini mode</source>
        <translation>ཁུ་བསྡུ་བྱེད་སྟངས་</translation>
    </message>
    <message>
        <location filename="../global/shortcutsetting.cpp" line="66"/>
        <source>to top</source>
        <translation>གོང་ནས་འོག་བར་དུ།</translation>
    </message>
    <message>
        <location filename="../global/shortcutsetting.cpp" line="67"/>
        <source>screenshot</source>
        <translation>བརྙན་ཤེལ་གྱི་པར་རིས།</translation>
    </message>
    <message>
        <location filename="../global/shortcutsetting.cpp" line="68"/>
        <source>cut</source>
        <translation>དྲས་གཏུབ་རྣམ་པ།</translation>
    </message>
    <message>
        <location filename="../global/shortcutsetting.cpp" line="69"/>
        <source>light up</source>
        <translation>འོད་ཆེམ་ཆེམ་དུ་</translation>
    </message>
    <message>
        <location filename="../global/shortcutsetting.cpp" line="70"/>
        <source>light down</source>
        <translation>འོད་སྣང་འཕྲོ་བ།</translation>
    </message>
    <message>
        <location filename="../global/shortcutsetting.cpp" line="71"/>
        <source>forward rotate</source>
        <translation>མདུན་སྐྱོད་ཀྱི་འཁོར་སྐྱོད།</translation>
    </message>
    <message>
        <location filename="../global/shortcutsetting.cpp" line="72"/>
        <source>backward rotate</source>
        <translation>རྗེས་ལུས་ཀྱི་འཁོར་སྐྱོད།</translation>
    </message>
    <message>
        <location filename="../global/shortcutsetting.cpp" line="73"/>
        <source>horizontal flip</source>
        <translation>འཕྲེད་ཕྱོགས་ཀྱི་འདྲུད་འཐེན་འཕྲུལ་</translation>
    </message>
    <message>
        <location filename="../global/shortcutsetting.cpp" line="74"/>
        <source>vertical flip</source>
        <translation>གཞུང་ཕྱོགས་ནས་ཕར་འགྲོ་ཚུར་འོང་བྱེད</translation>
    </message>
    <message>
        <location filename="../global/shortcutsetting.cpp" line="75"/>
        <source>image boost</source>
        <translation>པར་རིས་ལ་སྐུལ་འདེད་</translation>
    </message>
    <message>
        <location filename="../global/shortcutsetting.cpp" line="78"/>
        <source>volume up</source>
        <translation>གྲངས་འབོར་འཕར་སྣོན་བྱུང་བ</translation>
    </message>
    <message>
        <location filename="../global/shortcutsetting.cpp" line="79"/>
        <source>volume down</source>
        <translation>བོངས་ཚད་མར་ཆག་པ།</translation>
    </message>
    <message>
        <location filename="../global/shortcutsetting.cpp" line="80"/>
        <source>mute</source>
        <translation>སྐད་ཆ་མི་བཤད་པ།</translation>
    </message>
    <message>
        <location filename="../global/shortcutsetting.cpp" line="81"/>
        <source>audio next</source>
        <translation>གོམ་སྟབས་རྗེས་མར་སྒྲ་ཕབ</translation>
    </message>
    <message>
        <location filename="../global/shortcutsetting.cpp" line="82"/>
        <source>default channel</source>
        <translation>default ཐབས་ལམ།</translation>
    </message>
    <message>
        <location filename="../global/shortcutsetting.cpp" line="83"/>
        <source>left channel</source>
        <translation>གཡོན་ཕྱོགས་ཀྱི་བགྲོད་ལམ།</translation>
    </message>
    <message>
        <location filename="../global/shortcutsetting.cpp" line="84"/>
        <source>right channel</source>
        <translation>ཡང་དག་པའི་ཐབས་ལམ།</translation>
    </message>
    <message>
        <location filename="../global/shortcutsetting.cpp" line="87"/>
        <source>sub load</source>
        <translation>ཡན་ལག་གི་ཐེག་ཚད།</translation>
    </message>
    <message>
        <location filename="../global/shortcutsetting.cpp" line="90"/>
        <location filename="../global/shortcutsetting.cpp" line="95"/>
        <source>sub earlier</source>
        <translation>སྔ་མོ་ནས་ཡན་ལག་རུ་ཁག</translation>
    </message>
    <message>
        <location filename="../global/shortcutsetting.cpp" line="91"/>
        <location filename="../global/shortcutsetting.cpp" line="96"/>
        <source>sub later</source>
        <translation>རྗེས་སུ་ཡན་ལག་རུ་ཁག</translation>
    </message>
    <message>
        <location filename="../global/shortcutsetting.cpp" line="98"/>
        <source>sub up</source>
        <translation>ཡན་ལག་རུ་ཁག</translation>
    </message>
    <message>
        <location filename="../global/shortcutsetting.cpp" line="99"/>
        <source>sub down</source>
        <translation>འོག་ནས་མར་ཕབ་པ།</translation>
    </message>
    <message>
        <location filename="../global/shortcutsetting.cpp" line="100"/>
        <source>sub next</source>
        <translation>གོམ་སྟབས་རྗེས་མར་</translation>
    </message>
    <message>
        <location filename="../global/shortcutsetting.cpp" line="103"/>
        <source>play list</source>
        <translation>རྩེད་འཇོར་རོལ་བའི་མིང</translation>
    </message>
    <message>
        <location filename="../global/shortcutsetting.cpp" line="104"/>
        <source>setup</source>
        <translation>སྒྲིག་འཛུགས་བྱེད་པ།</translation>
    </message>
</context>
<context>
    <name>SystemTrayIcon</name>
    <message>
        <location filename="../widget/systemtrayicon.cpp" line="11"/>
        <source>Video Player</source>
        <translation>བརྙན་ཕབ་འཕྲུལ་འཁོར།</translation>
    </message>
    <message>
        <location filename="../widget/systemtrayicon.cpp" line="27"/>
        <source>Quit</source>
        <translation>ཕྱིར་འཐེན་བྱ་རྒྱུ།</translation>
    </message>
</context>
<context>
    <name>TitleMenu</name>
    <message>
        <location filename="../widget/kmenu.cpp" line="1017"/>
        <source>Upload to cloud</source>
        <translation>སྤྲིན་གྱི་སྟེང་དུ་བཀོད་པ།</translation>
    </message>
    <message>
        <location filename="../widget/kmenu.cpp" line="1021"/>
        <source>About</source>
        <translation>འབྲེལ་ཡོད་ཀྱི་སྐོར།</translation>
    </message>
    <message>
        <location filename="../widget/kmenu.cpp" line="1025"/>
        <source>Quit</source>
        <translation>ཕྱིར་འཐེན་བྱ་རྒྱུ།</translation>
    </message>
    <message>
        <location filename="../widget/kmenu.cpp" line="1035"/>
        <source>Theme</source>
        <translation>བརྗོད་བྱ་གཙོ་བོ།</translation>
    </message>
    <message>
        <location filename="../widget/kmenu.cpp" line="1043"/>
        <source>Follow system</source>
        <translation>ལམ་ལུགས་ལ་བརྩི་སྲུང་</translation>
    </message>
    <message>
        <location filename="../widget/kmenu.cpp" line="1051"/>
        <source>Light theme</source>
        <translation>འོད་ཟེར་བརྗོད་བྱ་གཙོ་བོ</translation>
    </message>
    <message>
        <location filename="../widget/kmenu.cpp" line="1059"/>
        <source>Black theme</source>
        <translation>བརྗོད་བྱ་གཙོ་བོ་ནག་</translation>
    </message>
    <message>
        <location filename="../widget/kmenu.cpp" line="1088"/>
        <source>Privacy</source>
        <translation>སྒེར་གྱི་གསང་དོན།</translation>
    </message>
    <message>
        <location filename="../widget/kmenu.cpp" line="1092"/>
        <location filename="../widget/kmenu.cpp" line="1096"/>
        <source>Video Player</source>
        <translation>བརྙན་ཕབ་འཕྲུལ་འཁོར།</translation>
    </message>
    <message>
        <location filename="../widget/kmenu.cpp" line="1092"/>
        <source>Are you sure you want to clear the list?</source>
        <translation>ཁྱོད་ཀྱིས་ངེས་པར་དུ་མིང་ཐོ་གཙང་བཤེར་བྱེད་དགོས་སམ།?</translation>
    </message>
    <message>
        <location filename="../widget/kmenu.cpp" line="1096"/>
        <source>The file being played will be stopped.</source>
        <translation>འདོན་སྤེལ་བྱེད་བཞིན་པའི་ཡིག་ཆ་དེ་བཀག་འགོག་བྱེད་རྒྱུ་རེད།.</translation>
    </message>
    <message>
        <location filename="../widget/kmenu.cpp" line="1104"/>
        <source>Clear mark</source>
        <translation>གསལ་པོར་རྟགས་རྒྱག་པ།</translation>
    </message>
    <message>
        <location filename="../widget/kmenu.cpp" line="1114"/>
        <source>No mark</source>
        <translation>རྟགས་མེད་པ།</translation>
    </message>
    <message>
        <location filename="../widget/kmenu.cpp" line="1128"/>
        <source>Help</source>
        <translation>རོགས་རམ་བྱེད་པ།</translation>
    </message>
    <message>
        <location filename="../widget/kmenu.cpp" line="1132"/>
        <source>Check update</source>
        <translation>ཞིབ་བཤེར་གསར་སྒྱུར།</translation>
    </message>
    <message>
        <location filename="../widget/kmenu.cpp" line="1145"/>
        <source>Manual</source>
        <translation>ལག་དེབ།</translation>
    </message>
    <message>
        <location filename="../widget/kmenu.cpp" line="1153"/>
        <source>Advice and feedback</source>
        <translation>བསམ་འཆར་དང་ལྡོག་འདྲེན།</translation>
    </message>
    <message>
        <location filename="../widget/kmenu.cpp" line="1159"/>
        <source>Official website</source>
        <translation>གཞུང་ཕྱོགས་ཀྱི་དྲ་ཚིགས།</translation>
    </message>
    <message>
        <location filename="../widget/kmenu.cpp" line="1174"/>
        <source>Setup</source>
        <translation>སྒྲིག་འཛུགས་བྱེད་པ།</translation>
    </message>
    <message>
        <location filename="../widget/kmenu.cpp" line="1178"/>
        <source>System setup</source>
        <translation>མ་ལག་སྒྲིག་ཆས།</translation>
    </message>
    <message>
        <location filename="../widget/kmenu.cpp" line="1182"/>
        <source>Play setup</source>
        <translation>རྩེད་འཇོར་རོལ་བའི་སྒྲིག་ཆས།</translation>
    </message>
    <message>
        <location filename="../widget/kmenu.cpp" line="1186"/>
        <source>Screenshot setup</source>
        <translation>པར་རིས་སྒྲིག་ཆས་</translation>
    </message>
    <message>
        <location filename="../widget/kmenu.cpp" line="1190"/>
        <source>Subtitle setup</source>
        <translation>ཡིག་བརྙན་གྱི་སྒྲིག་གཞི།</translation>
    </message>
    <message>
        <location filename="../widget/kmenu.cpp" line="1194"/>
        <source>Audio setup</source>
        <translation>སྒྲ་ཕབ་སྒྲིག་ཆས།</translation>
    </message>
    <message>
        <location filename="../widget/kmenu.cpp" line="1198"/>
        <source>Decoder setup</source>
        <translation>སྒྲིག་ཆས་སྒྲིག་འཛུགས་བྱེད་པ།</translation>
    </message>
    <message>
        <location filename="../widget/kmenu.cpp" line="1202"/>
        <source>Shortcut setup</source>
        <translation>མྱུར་བགྲོད་གཞུང་ལམ་སྒྲིག་ཆས།</translation>
    </message>
</context>
<context>
    <name>TitleWidget</name>
    <message>
        <location filename="../widget/titlewidget.cpp" line="54"/>
        <source>Restore</source>
        <translation>སླར་གསོ་བྱེད་པ།</translation>
    </message>
    <message>
        <location filename="../widget/titlewidget.cpp" line="59"/>
        <location filename="../widget/titlewidget.cpp" line="173"/>
        <source>Maximize</source>
        <translation>ཚད་གཞི་མཐོ་ཤོས་ཀྱི་སྒོ་ནས</translation>
    </message>
    <message>
        <location filename="../widget/titlewidget.cpp" line="129"/>
        <source>Video Player</source>
        <translation>བརྙན་ཕབ་འཕྲུལ་འཁོར།</translation>
    </message>
    <message>
        <location filename="../widget/titlewidget.cpp" line="141"/>
        <source>Menu</source>
        <translation>ཟས་ཐོ།</translation>
    </message>
    <message>
        <location filename="../widget/titlewidget.cpp" line="153"/>
        <source>Mini mode</source>
        <translation>རླངས་འཁོར་ཆུང་གྲས་ཀྱི་རྣམ</translation>
    </message>
    <message>
        <location filename="../widget/titlewidget.cpp" line="163"/>
        <source>Minimize</source>
        <translation>ཉུང་དུ་གཏོང་གང་ཐུབ་བྱ་དགོས།</translation>
    </message>
    <message>
        <location filename="../widget/titlewidget.cpp" line="183"/>
        <source>Close</source>
        <translation>སྒོ་རྒྱག་པ།</translation>
    </message>
</context>
<context>
    <name>TopWindow</name>
    <message>
        <source>Video Player</source>
        <translation type="vanished">བརྙན་ཕབ་འཕྲུལ་འཁོར།</translation>
    </message>
</context>
<context>
    <name>WaylandDialog</name>
    <message>
        <location filename="../widget/ukui-wayland/waylanddialog.ui" line="14"/>
        <source>Dialog</source>
        <translation>Dialog</translation>
    </message>
</context>
</TS>
